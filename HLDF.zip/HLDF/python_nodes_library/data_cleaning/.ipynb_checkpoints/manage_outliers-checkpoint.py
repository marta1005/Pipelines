import sys
import os.path

import pandas as pd
import numpy as np
from cytoolz.curried import map, get, compose, complement, flip
import ast
from scipy import stats as st

def filter_outliers_range(flow_variables, input_table):

    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    outputs_str = list(map(str.strip, outputs.strip('[]').split(',')))

    for output_range in flow_variables['metadata', 'Data_Cleansing', 'Managing_outliers', 'output'].values():
        name  = output_range['name']
        range = output_range['range']
        range_list = list(map(str.strip, range.strip('[]').split(',')))
        ranges = np.asarray(range_list, dtype=np.float64)
        print(f'Range for {name}: {range}')

        if name in outputs_str:
            input_table = input_table[input_table[name].between(ranges[0], ranges[1])]

    return input_table


def _parse_name_list(name_str: str) -> list:
    """
    Parse a string like "['x', 'y', 'z']" or "[x, y, z]" into ['x','y','z'],
    using only simple string operations.
    """
    s = str(name_str).strip()

    # quitar corchetes iniciales/finales si los hay
    if s.startswith('[') and s.endswith(']'):
        s = s[1:-1]

    if not s:
        return []

    parts = s.split(',')
    names = []
    for p in parts:
        p = p.strip()           # quita espacios
        p = p.strip("'\"")      # quita comillas simples o dobles
        if p:
            names.append(p)
    return names


def manage_outliers_zscore(dataset: pd.DataFrame,
                           flow_variables: dict,
                           verbose: bool = True) -> tuple[pd.DataFrame, dict]:
    """
    Detects and removes outliers in a dataset based on z-scores for both inputs and outputs.
    Reads input/output names as stringified lists from the flow_variables metadata.

    Parameters
    ----------
    dataset : pd.DataFrame
        Complete dataset containing both input and output columns.
    flow_variables : dict
        Global Surrogate Factory metadata structure.
        Must contain:
          - metadata -> Data_Cleaning -> Managing_outliers -> z_threshold
          - metadata -> Data_acquisition -> Extract -> input / output (as stringified lists)
    verbose : bool
        If True, prints information about detected and removed outliers.

    Returns
    -------
    dataset_clean : pd.DataFrame
        The full dataset with outlier rows removed.
    flow_variables : dict
        Updated metadata with summary of the operation.
    """

    # ---- Access metadata ----
    names_metadata = flow_variables["metadata"]["Data_acquisition_generation"]["Data_acquisition"]["Extract"]
    managing_cfg = flow_variables["metadata"]["Data_Cleansing"]["Managing_outliers"]

    # Parse stringified lists safely
    input_names = _parse_name_list(names_metadata["inputs"])
    output_names = _parse_name_list(names_metadata["outputs"])

    threshold = managing_cfg.get("z_threshold", 2.7)

    # ---- Safety check ----
    missing_cols = [col for col in input_names + output_names if col not in dataset.columns]
    if missing_cols:
        print(f"[WARNING] Missing columns in dataset: {missing_cols}")

    # ---- Compute z-scores ----
    z_scores_x = np.abs(st.zscore(dataset[input_names], nan_policy='omit'))
    z_scores_x = pd.DataFrame(z_scores_x, index=dataset.index, columns=input_names)
    outliers_x = (z_scores_x > threshold).any(axis=1)

    z_scores_y = np.abs(st.zscore(dataset[output_names], nan_policy='omit'))
    z_scores_y = pd.DataFrame(z_scores_y, index=dataset.index, columns=output_names)
    outliers_y = (z_scores_y > threshold).any(axis=1)

    # ---- Combine masks (global per-row filter) ----
    rows_outliers = outliers_x | outliers_y

    n_before = len(dataset)
    n_out_inputs = int(outliers_x.sum())
    n_out_outputs = int(outliers_y.sum())
    n_removed = int(rows_outliers.sum())
    n_after = n_before - n_removed

    # Remove the same rows from entire dataset
    dataset_clean = dataset[~rows_outliers].reset_index(drop=True)

    # ---- Update metadata ----
    managing_cfg.update({
        "method": "z-score",
        "z_threshold": float(threshold),
        "n_rows_before": int(n_before),
        "n_rows_after": int(n_after),
        "n_rows_removed": int(n_removed),
        "n_outliers_inputs": n_out_inputs,
        "n_outliers_outputs": n_out_outputs,
        "applied_to": {
            "inputs": input_names,
            "outputs": output_names
        }
    })

    flow_variables["metadata"]["Data_Cleansing"]["Managing_outliers"] = managing_cfg

    if verbose:
        print(f"[INFO] Outlier management (z-score={threshold})")
        print(f"  Inputs outliers:  {n_out_inputs}")
        print(f"  Outputs outliers: {n_out_outputs}")
        print(f"  Total removed:    {n_removed}")
        print(f"  Remaining rows:   {n_after}")

    return dataset_clean, flow_variables


