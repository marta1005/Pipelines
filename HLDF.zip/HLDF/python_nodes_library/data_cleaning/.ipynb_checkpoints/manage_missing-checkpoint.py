import pandas as pd
import surrogate_factory as sf


@sf.node
def replace_missing_values(flow_variables: sf.FlowVariables, input_table: pd.DataFrame):
    outputs = flow_variables['metadata', 'Data_Cleansing', 'Managing_missing_values', 'output']
    for v in outputs.values():
        if v['filling_value'] == 'mean': 
            v['filling_value'] = input_table[v['name']].mean()
        # input_table[v['name']].fillna(v['filling_value'], inplace=True)
        input_table[v['name']] = input_table[v['name']].fillna(v['filling_value'])

    inputs = flow_variables['metadata', 'Data_Cleansing', 'Managing_missing_values', 'input']
    for v in inputs.values():
        if v['filling_value'] == 'mean': 
            v['filling_value'] = input_table[v['name']].mean()
        # input_table[v['name']].fillna(v['filling_value'], inplace=True)
        input_table[v['name']] = input_table[v['name']].fillna(v['filling_value'])
    return input_table
