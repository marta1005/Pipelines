import json
import pandas as pd
import surrogate_factory as sf

@sf.node
def batch_extract(flow_variables, data) -> pd.DataFrame:
    """Extract function

    Args:
        flow_variables (_type_): _description_
        input_table (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """
    inputs  = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'inputs']
    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    # Clean inputs and outputs 
    inputs_clean  = (inputs.strip("[]").replace(' ','')).split(',')
    outputs_clean = (outputs.strip("[]").replace(' ','')).split(',')
    # Get inputs and outputs
    x_total = data[inputs_clean]
    yt_total = data[outputs_clean]

    # Make a file
    yt_total = yt_total.reset_index(drop=True)
    yt_total['id'] = yt_total.index + 1

    with open('output.csv', 'w') as f:
        for row in yt_total.itertuples(index=False):
            f.write(f"{{'id': {row.id}, 'O1':{row.O1}, 'O2':{row.O2}}}\n")

    yt_total = yt_total.drop(columns=['id'])
    return x_total, yt_total


@sf.node
def batch_transform(flow_variables, parsed_batches) -> pd.DataFrame:
    """ Transform function
        nothing to do in this example
    Args:
        flow_variables (_type_): _description_
        parsed_batches (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """
    transformed_batches = parsed_batches.copy()
    return transformed_batches


@sf.node
def batch_load(flow_variables, transformed_batches, input_table) -> pd.DataFrame:
    """_summary_

    Args:
        flow_variables (_type_): _description_
        transformed_batches (_type_): _description_
        input_table (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """

    return pd.concat([input_table, transformed_batches], axis=1)
