import pandas as pd
import pandas as pd
from typing import List, Tuple

def build_surrogate_dataset(
    x_files: List[str],
    y_files: List[str],
    x_columns: List[str],
    y_columns: List[str] = ["cp"],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Construye el dataset para un modelo surrogate leyendo múltiples CSV.
    
    Características de los CSV:
      - Separador ';'
      - Sin cabecera (header=None)

    Parámetros
    ----------
    x_files : list[str]
        Rutas a CSVs de entradas (X).
    y_files : list[str]
        Rutas a CSVs de salidas (y).
    x_columns : list[str]
        Nombres de columnas a asignar a X (debe coincidir con nº de columnas reales).
    y_columns : list[str], opcional (por defecto ["cp"])
        Nombres de columnas a asignar a y (debe coincidir con nº de columnas reales).

    Returns
    -------
    (X, y) : Tuple[pd.DataFrame, pd.DataFrame]
        DataFrames concatenados y validados.

    Raises
    ------
    ValueError:
        - Si no se proporcionan archivos o los archivos están vacíos.
        - Si el nº de columnas de algún CSV no coincide con los nombres solicitados.
        - Si el nº de filas de X y y no coincide tras concatenar.
    Exception:
        - Cualquier error de lectura se propaga con detalle del archivo.
    """
    
    if not x_files:
        raise ValueError("Debe indicarse al menos un archivo de X.")
    if not y_files:
        raise ValueError("Debe indicarse al menos un archivo de y.")

    def _read_and_validate(files: List[str], expected_cols: List[str]) -> pd.DataFrame:
        dfs = []
        for f in files:
            try:
                df = pd.read_csv(f, sep=";", header=None)
            except Exception as e:
                raise Exception(f"Error leyendo '{f}': {e}") from e

            if df.shape[1] != len(expected_cols):
                raise ValueError(
                    f"El archivo '{f}' tiene {df.shape[1]} columnas, "
                    f"pero se esperaban {len(expected_cols)} ({expected_cols})."
                )
            df.columns = expected_cols
            dfs.append(df)

        if not dfs:
            raise ValueError("No se ha leído ningún DataFrame válido.")
        return pd.concat(dfs, ignore_index=True)

    X = _read_and_validate(x_files, x_columns)
    y = _read_and_validate(y_files, y_columns)

    if X.shape[0] != y.shape[0]:
        raise ValueError(
            f"Desalineación de filas: X tiene {X.shape[0]} y y tiene {y.shape[0]} filas. "
            "Asegúrate de que los CSV de X e y se correspondan y estén concatenados en el mismo orden."
        )

    return X, y
