from pathlib import Path
import sys, os
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd

import matplotlib.pyplot as plt


def plot_train_test_loss(case_dir, loss_dict, save:bool = False):
    """
    Plots training and test loss curves.

    Parameters
    ----------
    loss_dict : dict
        Dictionary containing the training and test loss for each model. 
        Each value is a list or tensor of losses.
    save: bool
        If True, saves the plot to the 'plots' directory. If False, displays the plot.
    """
    plt.figure()
    for model_name, losses in loss_dict.items():
        # Asegurarse de que cada entrada sea una lista de floats
        if isinstance(losses, torch.Tensor):
            losses = losses.detach().cpu().numpy()
        elif isinstance(losses, list) and isinstance(losses[0], torch.Tensor):
            losses = [l.detach().cpu().item() for l in losses]

        plt.plot(range(1, len(losses) + 1), losses, label=f"{model_name} Loss")

    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Training curves for MLP, KAN")
    plt.yscale("log")
    plt.legend(loc='upper right')
    plt.grid()
    plt.tight_layout()
    if save:
        plt.savefig(os.path.join(case_dir,'plots'), dpi=300)
    plt.show()
