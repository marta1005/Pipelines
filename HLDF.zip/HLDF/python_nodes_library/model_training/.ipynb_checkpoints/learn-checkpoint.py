import os
import numpy as np
import torch
import joblib
from pathlib import Path
import surrogate_factory as sf
import pyLOM.NN
from pyLOM.NN import MLP


@sf.node
def train(flow_variables, Train_set, Val_set, train_dataset, val_dataset, test_dataset, model, training_params):
    """
    Custom train() function adapted for pyLOM MLP model training within Surrogate Factory.
    Includes automatic scaling of input and output variables before passing them to the pyLOM Pipeline.
    """

    # === 1️ Define job and paths ===
    job_name = flow_variables['job_name']
    models_path = Path(flow_variables["data.folder"], "models")
    models_path.mkdir(exist_ok=True)
    losses_path = Path(flow_variables["data.folder"], "losses")
    losses_path.mkdir(exist_ok=True)

    # === 2️ Load scalers (input & output) ===
    scaler_in, scaler_out = None, None
    if 'Feature_selection' in flow_variables['metadata'] and \
       'preprocess' in flow_variables['metadata']['Feature_selection']:
        for _, preprocess_def in flow_variables['metadata']['Feature_selection']['preprocess'].items():
            method = preprocess_def.get('method', '')
            if 'input' in preprocess_def:
                inputs = [col.strip().strip("'\"") for col in preprocess_def['input'].strip("[]").split(",")]
            else:
                inputs = []
            if 'output' in preprocess_def:
                outputs = [col.strip().strip("'\"") for col in preprocess_def['output'].strip("[]").split(",")]
            else:
                outputs = []

            if method != 'pyLOM.NN.MinMaxScaler()':
                file_path_in = preprocess_def.get('input_file', '')
                file_path_out = preprocess_def.get('output_file', '')
                if any(col in inputs for col in Train_set.columns):
                    scaler_in = joblib.load(file_path_in)
                    print(f"[INFO] Loaded input scaler from {file_path_in}")
                elif any(col in outputs for col in Train_set.columns):
                    scaler_out = joblib.load(file_path_out)
                    print(f"[INFO] Loaded output scaler from {file_path_out}")

    # === 3️ Scale datasets ===
    def scale_dataset(dataset, scaler_in, scaler_out):
        x_scaled = scaler_in.transform(dataset.variables_in) if scaler_in else dataset.variables_in
        y_scaled = scaler_out.transform(dataset.variables_out) if scaler_out else dataset.variables_out
        dataset.variables_in = x_scaled
        dataset.variables_out = y_scaled
        return dataset

    if scaler_in or scaler_out:
        train_dataset = scale_dataset(train_dataset, scaler_in, scaler_out)
        val_dataset = scale_dataset(val_dataset, scaler_in, scaler_out)
        test_dataset = scale_dataset(test_dataset, scaler_in, scaler_out)
        print("[INFO] Datasets scaled successfully.")

    # === 4️ Create pipeline and train ===
    pipeline_mlp = pyLOM.NN.Pipeline(
        model=model,
        train_dataset=train_dataset,
        valid_dataset=val_dataset,
        test_dataset=test_dataset,
        training_params=training_params
    )

    print(f"[INFO] Starting MLP training for job: {job_name}")
    training_logs = pipeline_mlp.run()

    # === 5️ Save results ===
    np.save(losses_path / f"{job_name}_training_losses.npy", training_logs, allow_pickle=True)
    model_file = models_path / f"mlp_{job_name}.pth"
    model.save(str(model_file))
    print(f"[INFO] Model saved to: {model_file}")

    # === 6️ Update metadata ===
    #flow_variables['metadata']['Model_Training']['Model']['MLP'] = str(model_file)
    flow_variables.setdefault("metadata",{}).setdefault("Model_Training",{}).setdefault('Model', {})['MLP'] = str(model_file)

    # === 7️ Return ===
    return model, training_logs
