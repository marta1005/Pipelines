import torch
from typing import Any, Dict


def build_training_params(flow_variables: Dict[str, Any], custom_loss = None) -> Dict[str, Any]:
    # Navigate to the correct model block
    try:
        param_block = flow_variables["metadata"]["Model_Selection"]["parameters"]
        cfg = param_block[next(iter(param_block))] if isinstance(param_block, dict) and param_block else param_block
    except Exception as e:
        raise KeyError("Could not locate ['metadata']['Model_Selection']['parameters'] in flow_variables.") from e

    # Helper to find a parameter value
    def get_value(key: str, default=None):
        for k, v in cfg.items():
            if key.lower() in k.lower():
                return v
        return default

    # Basic values
    batch_size = int(get_value("batch_size", 64))
    lr_init    = float(get_value("learning_rate_init", 1e-3))
    lr_gamma   = float(get_value("learning_rate_gamma", 0.99))
    lr_step    = int(get_value("learning_rate_scheduler", 1))
    num_workers = int(get_value("num_workers", 0))
    max_iter   = int(get_value("max_iter", 100))
    print_rate = int(get_value("print_rate_epoch", 1))
    loss_name  = str(get_value("loss", "mse")).lower()
    optim_name = str(get_value("optim", "adam")).lower()

    # Map optimizers to canonical torch classes
    if optim_name == "adam":
        optimizer_class = torch.optim.Adam
    elif optim_name == "sgd":
        optimizer_class = torch.optim.SGD
    elif optim_name == "adamw":
        optimizer_class = torch.optim.AdamW
    elif optim_name == "rmsprop":
        optimizer_class = torch.optim.RMSprop
    elif optim_name == "adagrad":
        optimizer_class = torch.optim.Adagrad
    else:
        optimizer_class = torch.optim.Adam  # default

    # Map losses to canonical torch.nn classes
    if loss_name in ("mse", "mse_loss"):
        loss_fn = torch.nn.MSELoss()
    elif loss_name in ("l1", "mae"):
        loss_fn = torch.nn.L1Loss()
    elif loss_name in ("crossentropy", "cross_entropy"):
        loss_fn = torch.nn.CrossEntropyLoss()
    elif loss_name in ("smoothl1", "huber"):
        loss_fn = torch.nn.SmoothL1Loss()
    else:
        loss_fn = torch.nn.MSELoss()
    # case of custom_loss
    if custom_loss is not None:
        loss_fn = custom_loss
    else:
        loss_fn = loss_fn()

    # Device
    device = "cpu" if torch.cuda.is_available() else "cpu"

    # Final dictionary
    training_params = {
        "epochs": max_iter,
        "lr_scheduler_step": lr_step,
        "optimizer_class": optimizer_class,  # e.g. torch.optim.Adam
        "loss_fn": loss_fn,                  # e.g. torch.nn.MSELoss
        "print_rate_epoch": print_rate,
        "num_workers": num_workers,
        "device": device,
        "lr": lr_init,
        "lr_gamma": lr_gamma,
        "batch_size": batch_size,
    }

    return training_params
