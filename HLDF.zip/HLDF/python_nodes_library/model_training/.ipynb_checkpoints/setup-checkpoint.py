import ast
from typing import Any, Dict, List, Sequence, Union
from pyLOM.NN import MLP

def _to_list(x: Union[str, Sequence[Any]], cast=None) -> List[Any]:
    # Accepts python-like string lists or list-like; trims and casts elements
    if isinstance(x, str):
        try:
            val = ast.literal_eval(x)
        except Exception:
            val = [t.strip() for t in x.strip().strip("[]").split(",") if t.strip() != ""]
    else:
        val = list(x)
    if cast is not None:
        val = [cast(v) for v in val]
    return val

def _int_or_str_int(x: Union[int, str]) -> int:
    # Ensures integer from int or numeric string
    if isinstance(x, int):
        return x
    return int(str(x).strip())

def build_model(flow_variables: Dict[str, Any]) -> MLP:
    # Locate model block under metadata/Model_Selection/model/<first_key>
    try:
        model_block = flow_variables["metadata"]["Model_Selection"]["model"]
        cfg = model_block[next(iter(model_block))] if isinstance(model_block, dict) and model_block else model_block
    except Exception as e:
        raise KeyError("Could not locate ['metadata']['Model_Selection']['model'] in flow_variables.") from e

    # Required keys
    try:
        algorithm = cfg["algorithm"]
        inputs    = cfg["input"]
        outputs   = cfg["output"]
        n_layers  = _int_or_str_int(cfg["n_layers"])
        n_neurons = _int_or_str_int(cfg["n_neurons"])
        dropout   = cfg["dropout"]
    except KeyError as e:
        raise KeyError(f"Missing required model key: {e}")

    # Algorithm check
    if str(algorithm).upper() != "MLP":
        raise NotImplementedError(f"Only 'MLP' is supported. Found: {algorithm}")

    # Names to sizes
    input_list  = _to_list(inputs,  cast=str)
    output_list = _to_list(outputs, cast=str)
    input_size  = len(input_list)
    output_size = len(output_list)

    # Hidden and dropouts as integers
    hidden_size = int(n_neurons)
    p_dropouts  = int(dropout)
    
    # Instantiate model
    model = MLP(
        input_size=input_size,
        output_size=output_size,
        hidden_size=hidden_size,
        n_layers=n_layers,
        p_dropouts=p_dropouts,
    )
    return model
