import mlflow
from datetime import datetime
import surrogate_factory as sf
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch, cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image, Table, TableStyle

styles = getSampleStyleSheet()
width = 595.27
height = 841.89
pagesize = (width, height)


def cover_page(canvas: Canvas, doc):
    title = 'Report'
    dat = datetime.today().strftime('%d.%m.%Y')
    canvas.saveState()
    canvas.setFont('Times-Roman', 18)
    canvas.drawCentredString(width/2.0, height-108, title)
    canvas.setFont('Times-Roman', 9)
    canvas.drawString(inch, 0.75*inch, dat)
    canvas.restoreState()


def doc_pages(canvas: Canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman', 9)
    canvas.drawString(inch, 0.75*inch, 'Page %d' % doc.page)
    canvas.restoreState()


@sf.node
def generate_pdf(flow_variables):

    # Get necessary (meta)data from pipeline json file.
    # Inputs and outputs.
    input_str = flow_variables['metadata', 'Requirements', 'model_inputs']
    output_str = flow_variables['metadata', 'Requirements', 'model_outputs']
    output = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    # Design of Experiment.
    doe_constraints = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Create_Design_of_Experiments', 'Design_Space', 'constraints']
    doe_algorithm = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Create_Design_of_Experiments', 'DoE', 'algorithm']
    doe_tool = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Create_Design_of_Experiments', 'DoE', 'tool']
    doe_size = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Create_Design_of_Experiments', 'DoE', 'size']
    # Run metadata.
    experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']
    algorithm = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'algorithm', 'algorithm']
    run_id = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'run_id']
    # Data partition.
    train_perc = flow_variables['metadata', 'Data_Partition', 'percentages', 'train']
    train_size = flow_variables['metadata', 'Data_Partition', 'size', 'train']
    test_perc = flow_variables['metadata', 'Data_Partition', 'percentages', 'test']
    test_size = flow_variables['metadata', 'Data_Partition', 'size', 'test']
    val_perc = flow_variables['metadata', 'Data_Partition', 'percentages', 'validation']
    val_size = flow_variables['metadata', 'Data_Partition', 'size', 'validation']
    # Requirements and Metrics.
    metrics = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'metrics']
    # Model settings.
    settings = flow_variables['metadata', 'Model_Selection', 'algorithms', '0', 'settings']
    # Local path.
    path = flow_variables['data.folder']

    # Get images.
    doe_input_graphs = str(f'{path}/img/doe_input.png')
    doe_output_graphs = str(f'{path}/img/doe_output.png')
    r2_plot_1 = str(f'{path}/img/lift coefficient_r2.png')
    r2_plot_2 = str(f'{path}/img/drag coefficient_r2.png')
    r2_plot_3 = str(f'{path}/img/moment coefficient_r2.png')

    if algorithm == 'neuralfoil':
        loss_graph = str(f'{path}/img/train_val_loss.png')

    elif algorithm == 'MLPRegressor':
        loss_graph = str(f'{path}/img/train_loss.png')

    # Create pdf from basic template.
    doc = SimpleDocTemplate(filename=f'report/Report_{run_id}.pdf')
    Story = [Spacer(1, 2*inch)]

    # Normal, left-aligned text.
    style = styles['Normal']
    style.alignment = 0

    # Normal, center-aligned text.
    center_style = styles['Normal']
    center_style.alignment = 1

    # Title text.
    title_style = styles['Heading1']

    # Add paragraph for the front page.
    description = ('<b>Surrogate Factory Pipeline</b> <br/>'
                   '<br/>'
                   f'Experiment: {experiment_name} <br/>'
                   f'Algorithm: {algorithm}')
    front = Paragraph(description, center_style)
    Story.append(front)
    Story.append(Spacer(1, 0.2*inch))
    Story.append(PageBreak())

    # Paragraphs for Model information.
    info_title = Paragraph('1 Model information', title_style)
    Story.append(info_title)
    Story.append(Spacer(1, 0.2*inch))

    # Inputs and Outputs.
    info_string = ('<b>Inputs</b> <br/>'
                   f'{input_str} <br/>'
                   '<br/>'
                   '<b>Outputs</b> <br/>'
                   f'{output_str}')
    info = Paragraph(info_string)
    Story.append(info)
    Story.append(Spacer(1, 0.2*inch))

    # Model settings.
    setting_string = ('<b>Settings</b> <br/>'
                      '<br/>'
                      'Relevant model settings.')
    setting = Paragraph(setting_string)
    Story.append(setting)
    Story.append(Spacer(1, 0.2*inch))

    if algorithm == 'MLPRegressor':

        # Create list of settings.
        set_data = []
        for key, val in settings.items():
            entry = [key, val]
            set_data.append(entry)

        settings_table = Table(set_data)
        settings_table.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.25, (0, 0, 0)),
                                            ('BOX', (0, 0), (-1, -1), 0.25, (0, 0, 0))]))

        settings_table.hAlign = 'LEFT'
        Story.append(settings_table)
        Story.append(Spacer(1, 0.2*inch))

    Story.append(PageBreak())

    # Paragraph for Data generation
    data_title = Paragraph('2 Data generation', title_style)
    Story.append(data_title)
    Story.append(Spacer(1, 0.2*inch))

    # Data generation.
    doe_string = ('<b>Design of Experiments settings</b>')
    doe = Paragraph(doe_string)
    Story.append(doe)
    Story.append(Spacer(1, 0.2*inch))

    doe_list = [['Algorithm for data generation', doe_algorithm], ['Tool', doe_tool],
                ['DoE size (number of data points)', doe_size], ['Constrained variables', doe_constraints]]
    doe_table = Table(doe_list)
    doe_table.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.25, (0, 0, 0)),
                                   ('BOX', (0, 0), (-1, -1), 0.25, (0, 0, 0))]))
    doe_table.hAlign = 'LEFT'
    Story.append(doe_table)
    Story.append(Spacer(1, 0.4*inch))

    # Data partitioning.
    part_string = ('<b>Data partitioning</b> <br/>'
                   '<br/>'
                   'Data set sizes.')
    part = Paragraph(part_string)
    Story.append(part)
    Story.append(Spacer(1, 0.2*inch))

    part_list = [['Training set', f'{train_size} ({train_perc*100}%)'], ['Validation set', f'{val_size} ({val_perc*100}%)'],
                 ['Test set', f'{test_size} ({test_perc*100}%)']]
    part_table = Table(part_list)
    part_table.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.25, (0, 0, 0)),
                                   ('BOX', (0, 0), (-1, -1), 0.25, (0, 0, 0))]))
    part_table.hAlign = 'LEFT'
    Story.append(part_table)
    Story.append(Spacer(1, 0.2*inch))

    visin_string = ('<b>Visualization of generated inputs</b>')
    visin = Paragraph(visin_string)
    Story.append(visin)
    Story.append(Spacer(1, 0.2*inch))

    doe_inputs = Image(doe_input_graphs, width=4.3*inch, height=4.7*inch)
    doe_inputs.hAlign = 'LEFT'
    Story.append(doe_inputs)
    Story.append(PageBreak())

    visout_string = ('<b>Visualization of simulated outputs</b>')
    visout = Paragraph(visout_string)
    Story.append(visout)
    Story.append(Spacer(1, 0.2*inch))

    doe_outputs = Image(doe_output_graphs, width=None, height=None)
    doe_outputs._restrictSize(6.4*inch, 7.2*inch)
    doe_outputs.hAlign = 'LEFT'
    Story.append(doe_outputs)
    Story.append(PageBreak())

    # Paragraphs for Model validation.
    # Metrics.
    valid_title = Paragraph('3 Model validation', title_style)
    Story.append(valid_title)
    Story.append(Spacer(1, 0.2*inch))
    v = Paragraph('<b>Metrics</b>')
    Story.append(v)
    Story.append(Spacer(1, 0.2*inch))

    # Create list for metrics table.
    data = []
    for key, val in metrics.items():
        entry = [key, val]
        data.append(entry)

    metrics_table = Table(data)
    metrics_table.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.25, (0, 0, 0)),
                                       ('BOX', (0, 0), (-1, -1), 0.25, (0, 0, 0))]))
    metrics_table.hAlign = 'LEFT'
    Story.append(metrics_table)
    Story.append(Spacer(1, 0.6*inch))

    # Loss graphs.
    loss_string = Paragraph('<b>Training and validation losses</b>')
    Story.append(loss_string)
    Story.append(Spacer(1, 0.2*inch))

    # Add image of loss graph.
    loss = Image(loss_graph, width=None, height=None)
    loss._restrictSize(6.4*inch, 7.2*inch)
    loss.hAlign = 'LEFT'
    Story.append(loss)
    Story.append(Spacer(1, 0.6*inch))

    # Comparison of test and prediction values.
    r2_string = Paragraph('<b>R\u00b2 scores</b>')
    Story.append(r2_string)
    Story.append(Spacer(1, 0.2*inch))

    # Add images of r2 plots.
    r2_1 = Image(r2_plot_1, width=None, height=None)
    r2_1._restrictSize(6.4*inch, 7.2*inch)
    r2_1.hAlign = 'LEFT'
    Story.append(r2_1)

    r2_2 = Image(r2_plot_2, width=None, height=None)
    r2_2._restrictSize(6.4*inch, 7.2*inch)
    r2_2.hAlign = 'LEFT'
    Story.append(r2_2)
    Story.append(Spacer(1, 0.4*inch))

    r2_3 = Image(r2_plot_3, width=None, height=None)
    r2_3._restrictSize(6.4*inch, 7.2*inch)
    r2_3.hAlign = 'LEFT'
    Story.append(r2_3)
    Story.append(Spacer(1, 0.4*inch))
    Story.append(PageBreak())

    # Build pdf with defined layouts.
    doc.build(Story, onFirstPage=cover_page, onLaterPages=doc_pages)
