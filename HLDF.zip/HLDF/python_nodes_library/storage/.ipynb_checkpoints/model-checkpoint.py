from pathlib import Path
import surrogate_factory as sf

import mlflow
import shutil
import joblib

import torch
import onnx
from pyLOM.NN import MLP


def _get_outdir(flow_variables: sf.FlowVariables, clean=False) -> Path:
    job_name = flow_variables['job_name']
    jobdir = Path(job_name)

    outdir = jobdir / ("models-cwrapper-" + job_name)
    outdir = outdir.resolve()
    if outdir.exists() and clean:
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    return outdir


def get_conda():
    import sklearn
    import orjson
    conda_env = mlflow.pyfunc.get_default_conda_env()
    conda_env['dependencies'][2]['pip'].append(f"scikit-learn=={sklearn.__version__}")
    conda_env['dependencies'][2]['pip'].append(f"orjson=={orjson.__version__}")

    return conda_env


@sf.node
def model_deployment(flow_variables):
    """
    Register the exported ONNX model as the deployed model.
    Reads info from metadata['Model_Export'] and writes to metadata['Model_Deployment'].
    """

    if "Model_Export" not in flow_variables["metadata"]:
        raise KeyError(
            "metadata['Model_Export'] not found. "
            "Run export_model_to_onnx before calling model_deployment."
        )

    export_info = flow_variables["metadata"]["Model_Export"]

    onnx_file = export_info.get("file", None)
    method = export_info.get("method", "ONNX")
    model_name = export_info.get("model_name", "MLP")

    if onnx_file is None:
        raise ValueError("No 'file' entry in metadata['Model_Export'].")

    print(f"[INFO] Deploying model from ONNX file: {onnx_file}")

    # Store deployment info (this is the "logical" registration step)
    flow_variables["metadata"]["Model_Deployment"] = {
        "method": method,
        "file": onnx_file,
        "model_name": model_name,
    }

    print("[INFO] Deployment info stored under metadata['Model_Deployment'].")
    return flow_variables


@sf.node
def upload_model(flow_variables):
    """Upload model wrapper

    Args:
        flow_variables (_type_): _description_
    """

    # not implemented in this example

    return flow_variables


@sf.node
def export_model(flow_variables):

    """
    Export a trained model to ONNX format and store export info in metadata['Model_Export'].
    The trained model path is read from metadata['Model_Training']['Model'].
    """

    # 1) Get model path from metadata (Model_Training → Model)
    model_meta = flow_variables["metadata"]["Model_Training"]["Model"]

    # It can be a string (direct path) or a dict {model_name: path}
    if isinstance(model_meta, str):
        model_name = "MLP"
        model_path = model_meta
    elif isinstance(model_meta, dict):
        model_name, model_path = next(iter(model_meta.items()))
    else:
        raise ValueError(
            f"Unexpected type for metadata['Model_Training']['Model']: {type(model_meta)}. "
            "Expected str or dict."
        )

    print(f"[INFO] Exporting trained model from: {model_path}")

    # 2) Load model object depending on extension
    if model_path.endswith(".modl"):
        model = joblib.load(model_path)
        if not isinstance(model, torch.nn.Module):
            raise TypeError(
                f"[ERROR] Model in {model_path} is not a torch.nn.Module. "
                "ONNX export currently expects a PyTorch nn.Module."
            )
        model.eval()

    elif model_path.endswith(".pth"):
        # pyLOM model saved with model.save(...)
        try:
            loaded = MLP.load(model_path)
        except Exception as e:
            raise RuntimeError(
                f"[ERROR] Could not load MLP from {model_path} using MLP.load(). "
                f"Original error: {e}"
            )

        # Handle possible (model, extra) return
        if isinstance(loaded, tuple):
            model = loaded[0]
        else:
            model = loaded

        if not isinstance(model, torch.nn.Module):
            raise TypeError(
                f"[ERROR] MLP.load({model_path}) did not return nn.Module. "
                f"Returned type: {type(model)}"
            )

        model.eval()

    else:
        raise ValueError(f"Unsupported model format for export: {model_path}")

    # 4) Prepare export directory
    export_dir = Path(flow_variables["data.folder"]) / "exported_models"
    export_dir.mkdir(parents=True, exist_ok=True)

    # 5) Export to ONNX
    onnx_path = export_dir / f"{flow_variables['job_name']}_{model_name}.onnx"

    # 6) Validate the export
    try:
        onnx_model = onnx.load(onnx_path)
        onnx.checker.check_model(onnx_model)
        print("[INFO] ONNX model validated successfully.")
    except Exception as e:
        print(f"[WARNING] ONNX validation failed: {e}")

    # 7) Store export info in metadata
    flow_variables["metadata"]["Model_Export"] = {
        "method": "ONNX",
        "file": str(onnx_path),
        "source_model_file": model_path,
        "model_name": model_name,
    }

    print("[INFO] Export info stored under metadata['Model_Export'].")
    