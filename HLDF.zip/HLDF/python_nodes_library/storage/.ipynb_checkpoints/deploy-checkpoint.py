import os
from pathlib import Path

import torch
import onnx
import surrogate_factory as sf
from pyLOM.NN import MLP


@sf.node
def model_deployment(flow_variables):
    """
    Export the trained model to ONNX format using input size from metadata.
    The model is moved to CUDA if available.
    """

    # === 1️⃣ Get model path ===
    model_meta = flow_variables["metadata"]["Model_Training"]["Model"]
    if isinstance(model_meta, str):
        model_name = "MLP"
        model_path = model_meta
    elif isinstance(model_meta, dict):
        model_name, model_path = next(iter(model_meta.items()))
    else:
        raise ValueError(f"Unexpected type for model metadata: {type(model_meta)}")

    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")

    print(f"[INFO] Loading trained model '{model_name}' from: {model_path}")

    # === 2️⃣ Load model ===
    loaded = MLP.load(model_path)
    model = loaded[0] if isinstance(loaded, tuple) else loaded

    if not isinstance(model, torch.nn.Module):
        raise TypeError(f"Loaded object is not a torch model: {type(model)}")

    # === 3️⃣ Move to CUDA if available ===
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()
    print(f"[INFO] Model moved to device: {device}")

    # === 4️⃣ Get input names and infer input size from metadata ===
    inputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "inputs"]
    if isinstance(inputs, str):
        inputs = [x.strip().strip("'\"") for x in inputs.strip("[]").split(",") if x.strip()]

    input_size = len(inputs)
    if input_size == 0:
        raise ValueError("No input variables found in metadata — cannot infer input size.")

    print(f"[INFO] Input size inferred from metadata = {input_size}")

    # === 5️⃣ Build example tensor (required by ONNX) ===
    example_x = torch.zeros(1, input_size, dtype=torch.float32).to(device)

    # === 6️⃣ Export to ONNX ===
    export_dir = Path(flow_variables["data.folder"]) / "exported_models"
    export_dir.mkdir(parents=True, exist_ok=True)

    onnx_path = export_dir / f"{flow_variables['job_name']}_{model_name}.onnx"
    print(f"[INFO] Exporting ONNX to: {onnx_path}")

    torch.onnx.export(
        model,
        example_x,
        onnx_path,
        export_params=True,
        opset_version=11,
        do_constant_folding=True,
        input_names=["input"],
        output_names=["output"],
        dynamic_axes={"input": {0: "batch_size"}, "output": {0: "batch_size"}},
    )

    print(f"[INFO] ONNX export completed: {onnx_path}")

    # === 7️⃣ Save metadata ===
    flow_variables["metadata"]["Model_Deployment"] = {
        "method": "ONNX",
        "file": str(onnx_path),
        "device": str(device),
        "model_name": model_name,
    }

    print(f"[INFO] Model deployment info stored in metadata['Model_Deployment'].")
   
