import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import r2_score


def pair_plot(flow_variables, title, input_table, sample=True, density=False):

    path = flow_variables['data.folder']

    if sample:
        input_table = input_table.sample(frac = 0.1)
    if density:
        diag_kind = 'kde'
    else:
        diag_kind = 'auto'

    fig = sns.pairplot(input_table, diag_kind = diag_kind)
    fig_save = fig.figure
    fig_save.savefig(f'./plots/{title}.png', bbox_inches='tight')
    return fig


def pred_plot(flow_variables, title, test_table, pred_table, r2):

    path = flow_variables['data.folder']

    fig, axs = plt.subplots(1, 1, figsize=(10, 6))
    axs.scatter(test_table, pred_table)
    axs.set(xlabel=f'actual {title}', ylabel=f'predicted {title}', title=title)
    # axs.set_xlabel(f'actual {title}')
    # axs.set_ylabel(f'predicted {title}')

    r2_text = f'$R^2$: {r2:.3f}'
    box_style = dict(boxstyle='square', facecolor='#b1d1fc')

    axs.text(x=0.05, y=0.95, s=r2_text, transform=axs.transAxes, fontsize=14, verticalalignment='top', bbox=box_style)

    sns.regplot(x=test_table, y=pred_table, ci=False, line_kws={'color': 'red'}, ax=axs)
    fig.savefig(f'./plots/{title}_r2.png', bbox_inches='tight')

    return fig


def box_plot(input_table, sample = True):
    if sample:
        input_table = input_table.sample(frac = 0.1)
    f, ax = plt.subplots()
    ax.boxplot(input_table)
    return ax
