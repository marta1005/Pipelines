import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import validationlib
from IPython.display import display


def train_test_split_analysis(train, test, input_names):
    # Train-test split
    validationlib.plots.doubleHistogram(
        train[input_names], 
        test[input_names], 
        xlabel='Ouptut',
        x1label='Train',
        x2label='Test',
        multiPlotsKwargs={
            "tight_layout": True
        }
    )
    plt.show()
    # table
    table_pval_num = validationlib.tests.dist.dist_similarity_table(
        train[input_names], 
        test[input_names], 
        title="p-values",
        tests=["KS", "AD"]
    )
    display(table_pval_num)
    
def compute_statistics_table(x_df, precision=3, nsim=100, method="Bootstrap"):
    """
    Returns a summary table of general statistics for the provided dataframe.
    The table is rendered automatically when returned from a notebook cell.
    """
    statistics = {
        "mean": np.mean,
        "median": [np.percentile, {"q": 50}],
        "std": np.std,
        "IQR": st.iqr,
        "kurtosis": st.kurtosis,
        "skewness": st.skew
    }

    displayed_table = validationlib.tables.summary.prediction_stats(
        x_df,
        statistics=statistics,
        precision=precision,
        nsim=nsim,
        method=method
    )
    return displayed_table  # ← se muestra directamente como output del notebook


def compute_percentile_table(x_df, precision=3, nsim=100, method="Bootstrap"):
    """
    Returns a table of selected percentiles (1%, 5%, 10%, 50%, 90%, 95%, 99%).
    """
    statistics_percentile = {
        f"{i}%": [np.percentile, {"q": i}] for i in [1, 5, 10, 50, 90, 95, 99]
    }

    displayed_table = validationlib.tables.summary.prediction_stats(
        x_df,
        statistics=statistics_percentile,
        precision=precision,
        nsim=nsim,
        method=method,
        countMinMax=False
    )
    return displayed_table  # ← también se mostrará directamente


def plot_validation_distributions(x_df, xlabel="Input Variable", bins=1000):
    """
    Generates histogram and cumulative distribution plots for validation data.
    """
    validationlib.plots.histogram(
        x_df,
        xlabel=xlabel,
        trimStds=3,
        multiPlotsKwargs={"tight_layout": True},
        logscale=True
    )
    plt.show()

    validationlib.plots.cumulative(
        x_df,
        xlabel="Ground truth",
        bins=bins,
        quantiles=[0.1, 0.50, 0.90, 0.95, 0.99]
    )
    plt.show()


def full_validation_analysis(x_df):
    """
    Executes the complete validation analysis (statistics, percentiles, and plots)
    and returns all generated tables.
    """
    stats_table = compute_statistics_table(x_df)
    percentiles_table = compute_percentile_table(x_df)
    plot_validation_distributions(x_df)

    return stats_table, percentiles_table 
