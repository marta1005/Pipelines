import numpy as np
import torch
import pyLOM.NN
from sklearn.preprocessing import MinMaxScaler, StandardScaler, RobustScaler
import joblib
from pathlib import Path
import surrogate_factory as sf


@sf.node
def preprocessor(flow_variables, input_table):
    """
    Fits and saves scalers for both INPUTS and OUTPUTS defined in metadata.
    Supports pyLOM.NN and sklearn scalers.
    Handles names like "[x, y, z]" or lists.
    """

    scaler_fit = {"inputs": None, "outputs": None}

    for i, preprocess_def in flow_variables['metadata', 'Feature_selection', 'preprocess'].items():
        method = preprocess_def['method']

        # --- Parse lists of column names ---
        def parse_list(raw):
            if isinstance(raw, str):
                return [c.strip().strip("'\"") for c in raw.strip("[]").split(",") if c.strip()]
            elif isinstance(raw, list):
                return raw
            else:
                return []

        inputs = parse_list(preprocess_def.get('input', []))
        outputs = parse_list(preprocess_def.get('output', []))

        # --- Select scaler ---
        if method == 'pyLOM.NN.MinMaxScaler()':
            ScalerClass = pyLOM.NN.MinMaxScaler
            backend = "pylom"
        elif method == 'pyLOM.NN.StandardScaler()':
            ScalerClass = pyLOM.NN.StandardScaler
            backend = "pylom"
        elif method == 'pyLOM.NN.RobustScaler()':
            ScalerClass = pyLOM.NN.RobustScaler
            backend = "pylom"
        elif method == 'sklearn.preprocessing.MinMaxScaler':
            ScalerClass = MinMaxScaler
            backend = "sklearn"
        elif method == 'sklearn.preprocessing.StandardScaler':
            ScalerClass = StandardScaler
            backend = "sklearn"
        elif method == 'sklearn.preprocessing.RobustScaler':
            ScalerClass = RobustScaler
            backend = "sklearn"
        else:
            raise ValueError(f"Unknown scaling method: {method}")

        job_name = flow_variables['job_name']
        models_path = Path(flow_variables["data.folder"], "models")
        models_path.mkdir(exist_ok=True)

        # === Scale INPUTS ===
        if inputs:
            data_np = input_table[inputs].to_numpy(dtype=np.float32)
            if backend == "pylom":
                data = torch.tensor(data_np, dtype=torch.float32)
                scaler_in = ScalerClass().fit(data)
            else:
                scaler_in = ScalerClass().fit(data_np)

            scaler_fit["inputs"] = scaler_in

            file_in = models_path / f'scaler_{job_name}_inputs.pkl'
            joblib.dump(scaler_in, file_in)
            flow_variables['metadata']['Feature_selection']['preprocess'][i]['input_file'] = str(file_in)

            print(f"[INFO] Fitted {method} for INPUT columns: {inputs}")
            print(f"       Saved to: {file_in}")

        # === Scale OUTPUTS ===
        if outputs:
            data_np = input_table[outputs].to_numpy(dtype=np.float32)
            if backend == "pylom":
                data = torch.tensor(data_np, dtype=torch.float32)
                scaler_out = ScalerClass().fit(data)
            else:
                scaler_out = ScalerClass().fit(data_np)

            scaler_fit["outputs"] = scaler_out

            file_out = models_path / f'scaler_{job_name}_outputs.pkl'
            joblib.dump(scaler_out, file_out)
            flow_variables['metadata']['Feature_selection']['preprocess'][i]['output_file'] = str(file_out)

            print(f"[INFO] Fitted {method} for OUTPUT columns: {outputs}")
            print(f"       Saved to: {file_out}")
