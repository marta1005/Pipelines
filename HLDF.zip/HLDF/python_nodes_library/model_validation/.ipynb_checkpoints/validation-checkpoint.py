import os
import json
import numpy as np
import pandas as pd
import torch
import joblib
import pyLOM
from pyLOM.NN import RegressionEvaluator
import surrogate_factory as sf


@sf.node
def validate_model(flow_variables, model, train_dataset, val_dataset, test_dataset):
    """
    Validation node for pyLOM models integrated in Surrogate Factory.
    Automatically converts pandas DataFrames into pyLOM datasets
    using inputs/outputs defined in metadata.
    Evaluates train/val/test datasets, stores predictions and metrics,
    and updates flow_variables with validation results.
    """

    # === Define job and paths ===
    job_name = flow_variables["job_name"]
    case_dir = flow_variables["data.folder"]
    save_dir = os.path.join(case_dir, "validation_files", job_name)
    os.makedirs(save_dir, exist_ok=True)

    # === Load dataloader params ===
    dataloader_dict = flow_variables["metadata"]["Model_Validation"].get("dataloader", {})
    if isinstance(dataloader_dict, dict) and 0 in dataloader_dict:
        dataloader_params = dataloader_dict[0]
    else:
        dataloader_params = dataloader_dict
    print(f"[INFO] Dataloader params: {dataloader_params}")

    # === Load evaluator ===
    evaluator_class = flow_variables["metadata"]["Model_Validation"]["evaluator"]
    evaluator = eval(evaluator_class)() if isinstance(evaluator_class, str) else evaluator_class

    # === Load scalers ===
    scaler_in, scaler_out = None, None
    preprocess_dict = flow_variables["metadata"]["Feature_selection"].get("preprocess", {})

    for _, preprocess_def in preprocess_dict.items():
        file_path_in = preprocess_def.get("input_file", "")
        file_path_out = preprocess_def.get("output_file", "")

        if file_path_in and os.path.exists(file_path_in):
            try:
                scaler_in = joblib.load(file_path_in)
                print(f"[INFO] Loaded INPUT scaler from {file_path_in}")
            except Exception as e:
                print(f"[ERROR] Could not load INPUT scaler from {file_path_in}: {e}")

        if file_path_out and os.path.exists(file_path_out):
            try:
                scaler_out = joblib.load(file_path_out)
                print(f"[INFO] Loaded OUTPUT scaler from {file_path_out}")
            except Exception as e:
                print(f"[ERROR] Could not load OUTPUT scaler from {file_path_out}: {e}")

    if scaler_in is None:
        print("[WARNING] No input scaler found — using identity transform.")
        class IdentityScaler:
            def transform(self, x): return x
            def inverse_transform(self, x): return x
        scaler_in = IdentityScaler()

    if scaler_out is None:
        print("[WARNING] No output scaler found — using identity transform.")
        class IdentityScaler:
            def transform(self, x): return x
            def inverse_transform(self, x): return x
        scaler_out = IdentityScaler()

    # === Convert DataFrames to pyLOM datasets if needed ===
    def to_pylom_dataset(data):
        if isinstance(data, pd.DataFrame):
            inputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "inputs"]
            outputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "outputs"]

            if isinstance(inputs, str):
                inputs = list(map(str.strip, inputs.strip('[]').split(',')))
            if isinstance(outputs, str):
                outputs = list(map(str.strip, outputs.strip('[]').split(',')))

            X = torch.tensor(data[inputs].values, dtype=torch.float32)
            Y = torch.tensor(data[outputs].values, dtype=torch.float32)
            return torch.utils.data.TensorDataset(X, Y)
        else:
            return data

    train_dataset = to_pylom_dataset(train_dataset)
    val_dataset = to_pylom_dataset(val_dataset)
    test_dataset = to_pylom_dataset(test_dataset)

    # === Define evaluation function ===
    def evaluate(model, training_params, dataset, evaluator, input_scaler, output_scaler):
        y_pred = model.predict(dataset, rescale_output=True, **training_params)
        y_pred = output_scaler.inverse_transform(y_pred)

        x_true, y_true = dataset[:]
        x_true = input_scaler.inverse_transform(x_true)
        y_true = output_scaler.inverse_transform(y_true)

        metrics = evaluator(y_true, y_pred)
        evaluator.print_metrics()
        return metrics, (x_true, y_true, y_pred)

    # === Evaluate datasets and save predictions === 🟩
    datasets = [train_dataset, val_dataset, test_dataset]
    dataset_names = ["train", "val", "test"]
    all_metrics = {}
    prediction_paths = {}

    for dataset, name in zip(datasets, dataset_names):
        print(f"[INFO] Evaluating dataset: {name}")
        metrics, (x_true, y_true, y_pred) = evaluate(model, dataloader_params, dataset, evaluator, scaler_in, scaler_out)
        all_metrics[name] = metrics

        # Save predictions to CSV
        x_file = os.path.join(save_dir, f"x_{name}.csv")
        yt_file = os.path.join(save_dir, f"yt_{name}.csv")
        yh_file = os.path.join(save_dir, f"yh_{name}.csv")
        npy_file = os.path.join(save_dir, f"predictions_{name}.npy")

        pd.DataFrame(x_true).to_csv(x_file, index=False, sep=";", header=None)
        pd.DataFrame(y_true).to_csv(yt_file, index=False, sep=";", header=None)
        pd.DataFrame(y_pred).to_csv(yh_file, index=False, sep=";", header=None)
        np.save(npy_file, np.array(y_pred))

        prediction_paths[name] = {
            "x_file": x_file,
            "yt_file": yt_file,
            "yh_file": yh_file,
            "npy_file": npy_file
        }

        print(f"[INFO] Saved predictions for {name} dataset to {save_dir}")

    # === Save metrics summary ===
    metrics_file = os.path.join(save_dir, "metrics_summary.json")
    with open(metrics_file, "w") as f:
        json.dump(all_metrics, f, indent=4)
    print(f"[INFO] Metrics saved to: {metrics_file}")

    # === Update flow_variables ===
    flow_variables["metadata", "Model_Validation", "results"] = {
        "path": save_dir,
        "metrics_file": metrics_file,
        "metrics": all_metrics,
        "predictions": prediction_paths
    }

    print("[INFO] Validation metrics and predictions stored in flow_variables.")
    return all_metrics
