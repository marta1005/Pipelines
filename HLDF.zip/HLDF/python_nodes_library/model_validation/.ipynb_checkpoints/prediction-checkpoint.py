import numpy as np
import torch
from pyLOM.NN import RegressionEvaluator
from typing import Any, Dict

seed = 380
np.random.seed(seed)
torch.manual_seed(seed)


def build_validation_components(flow_variables: Dict[str, Any]):
    """Extract dataloader parameters, evaluator, and scalers from flow_variables."""

    try:
        validation_block = flow_variables["metadata"]["Model_Validation"]
    except Exception as e:
        raise KeyError("Could not locate ['metadata']['Model_Validation'] in flow_variables.") from e

    # ---- Extract dataloader parameters ----
    try:
        dataloader_block = validation_block["dataloader"]
        # Handle {'0': {...}} or direct dict
        if isinstance(dataloader_block, dict) and any(isinstance(v, dict) for v in dataloader_block.values()):
            dataloader_cfg = next(iter(dataloader_block.values()))
        else:
            dataloader_cfg = dataloader_block
    except Exception as e:
        raise KeyError("Could not locate ['dataloader'] parameters in flow_variables.") from e

    def get_value(container: Dict[str, Any], key: str, default=None):
        for k, v in container.items():
            if key.lower() == k.lower():
                return v
        return default

    # Dataloader params
    batch_size  = int(get_value(dataloader_cfg, "batch_size", 32))
    shuffle = bool(get_value(dataloader_cfg, "shuffle", True))
    num_workers = int(get_value(dataloader_cfg, "num_workers", 0))
    pin_memory  = bool(get_value(dataloader_cfg, "pin_memory", False))

    dataloader_params = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
    }

    # ---- Extract evaluator and scalers (same level as dataloader) ----
    evaluator_name = str(validation_block.get("evaluator", "RegressionEvaluator")).lower()

    # Evaluator
    if "regression" in evaluator_name:
        evaluator = RegressionEvaluator()
    else:
        raise NotImplementedError(f"Unsupported evaluator: {evaluator_name}")

    return dataloader_params, evaluator
