import numpy as np
import surrogate_factory as sf


@sf.node
def data_split(flow_variables, input_table):
    """_summary_
    Function to split data in the 3 datasets for training, test and validation
    flow_variables should be updated accordingly
    Args:
        flow_variables (_type_): flow_variables of the pipeline
        input_table (_type_): Dataset to split

    Returns:
        Train_set: pandas DataFrame
        Test_set: pandas DataFrame
        Val_set: pandas DataFrame

    """

    train_perc = flow_variables["metadata", "Data_Partition", "percentages", "train"]
    test_perc = (flow_variables["metadata", "Data_Partition", "percentages", "test"])
    val_perc = 1 - test_perc

    inputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'inputs']
    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))

    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))

    for input_name in input_table.columns.values:
        if (input_name not in inputs) and (input_name not in outputs):
            input_table = input_table.drop(input_name, axis=1)
            print(f'{input_name} removed as input.')

    train_set, val_set, test_set = np.split(input_table.sample(frac=1, random_state=42), [int(train_perc*len(input_table)), int(val_perc*len(input_table))])

    flow_variables['metadata', 'Data_Partition', 'size', 'train'] = train_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'test'] = test_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'validation'] = val_set.shape[0]

    return train_set, val_set, test_set

