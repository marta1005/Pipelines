import sys
import os.path

import pandas as pd
import numpy as np
from cytoolz.curried import map, get, compose, complement, flip

import surrogate_factory as sf


@sf.node
def filter_outliers(flow_variables, input_table):

    model_vars = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'inputs']
    model_vars = list(map(str.strip, model_vars.strip('[]').split(',')))
    outputs_str = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    output_vars = list(map(str.strip, outputs_str.strip('[]').split(',')))
    print(model_vars, output_vars)
    inputs = input_table[model_vars]
    outputs = input_table[output_vars]

    output_range = flow_variables['metadata', 'Data_Cleansing', 'Managing_outliers', 'output'][0]['range']
    # output_range_list = list(map(str.strip, output_range.strip('[]').split(',')))

    # indices = outputs[outputs.isin(output_range_list)].index
    # indices = outputs[outputs.between(output_range_list).any()].index

    # return input_table.iloc[indices]
    return input_table
