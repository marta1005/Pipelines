import pandas as pd
import numpy as np
import surrogate_factory as sf


@sf.node
def replace_missing_values(flow_variables: sf.FlowVariables, input_table: pd.DataFrame):
    outputs = flow_variables['metadata', 'Data_Cleansing', 'Managing_missing_values', 'output']
    for v in outputs.values():
        # input_table[v['name']].fillna(v['filling_value'], inplace=True)
        input_table[v['name']] = input_table[v['name']].fillna(v['filling_value'])

        # The behavior will change in pandas 3.0.
        # This inplace method will never work because the intermediate object on which we are setting values always behaves as a copy.
        # For example, when doing 'df[col].method(value, inplace=True)',
        # try using 'df.method({col: value}, inplace=True)' or df[col] = df[col].method(value) instead,
        # to perform the operation inplace on the original object.

    return input_table
