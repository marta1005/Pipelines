import sys
import os.path

import isami
from doe import DoE
from pathlib import Path
import pandas as pd
from operator import itemgetter
from typing import Dict, Union
import surrogate_factory as sf

# isami items
items = [
    isami.Item("FastenerSystem Table", **{"AirbusEO_TFastenerSystem": "A321neo_default_fastener",
                                          "pin": "NAS1097KE",
                                          "nutCollar": "",
                                          "diameter": 4.78}),
    isami.Item("FastenerSystem Table", **{"AirbusEO_TFastenerSystem": "A321_lower_shell_fastener",
                                          "pin": "NAS1097KE",
                                          "nutCollar": "",
                                          "diameter": 3.96}),
    isami.Item("FastenerSystem Table", **{"AirbusEO_TFastenerSystem": "Fastener",
                                          "pin": "ABS0548VHK",
                                          "nutCollar": "ASNA2025",
                                          "diameter": 4.78}),
    isami.Item("FastenerSystem Table", **{"AirbusEO_TFastenerSystem": "Fastener_CB",
                                          "pin": "NAS1151",
                                          "nutCollar": "MS21042",
                                          "diameter": 3.51}),
    isami.Item("Material Table", **{"Material label": "2024_T3",
                                    "Library": "Referenced",
                                    "Material name": "2024-Clad_T3_Sheet",
                                    "Specification": "AIMS03-04-011_AIMS03-04-014"}),
    isami.Item("Material Table", **{"Material label": "2024_T42",
                                    "Library": "Referenced",
                                    "Material name": "2024-Clad_T42_Sheet",
                                    "Specification": "AIMS03-04-010"}),
    isami.Item("Material Table", **{"Material label": "Skin Panel 2024HDT-T351",
                                    "Library": "Referenced",
                                    "Material name": "2524-Clad_T351_Plate",
                                    "Specification": "AIMS03-04-022"}),
    isami.Item("Material Table", **{"Material label": "Stringers 7349 T76511",
                                    "Library": "Referenced",
                                    "Material name": "7359_T76511_Extruded",
                                    "Specification": "AIMS03-05-033"}),
    isami.Item("Material Table", **{"Material label": "CB 2196_T8511_extruded",
                                    "Library": "Referenced",
                                    "Material name": "2196_T8511_Extruded",
                                    "Specification": "AIMS03-05-032"}),
    isami.Item("Metallic Profile Table", **{"Profile": "doubler_2",
                                            "MatType": "Metal",
                                            "StructType": "Dou",
                                            "Family": "0",
                                            "Number": "02",
                                            "Variant": "a",
                                            "MetallicMaterial": "2024_T42",
                                            "Billet": 4,
                                            "bd": 50,
                                            "dd": 25,
                                            "td": 3}),
    isami.Item("Metallic Profile Table", **{"Profile": "frame_1",
                                            "MatType": "Metal",
                                            "StructType": "Fra",
                                            "Family": "Z",
                                            "Number": "2",
                                            "Variant": "b",
                                            "MetallicMaterial": "2024_T42",
                                            "Billet": 4,
                                            "ba": 20,
                                            "bf": 20,
                                            "blf": 8,
                                            "h": 60,
                                            "ra": 4,
                                            "rf": 4,
                                            "rlf": 4,
                                            "t": 1.8,
                                            "ta": 1.8,
                                            "tf": 1.8,
                                            "tlf": 1.8,
                                            "tw": 1.8}),
    isami.Item("Joint Table", **{"AirbusEO_TJoint": "Joint_Stringer-Skin",
                                 "EquallyDistributed": True,
                                 "TranslationXfs": -1.55,
                                 "TranslationYfs": 0,
                                 "NbXfs": 1,
                                 "NbYfs": 1,
                                 "XfsPitch": 0,
                                 "YfsPitch": 25,
                                 "FastenerID for All": True,
                                 "F1_FID": "A321neo_default_fastener"}),
    isami.Item("Joint Table", **{"AirbusEO_TJoint": "Joint_Frame-Skin",
                                 "EquallyDistributed": True,
                                 "TranslationXfs": 30,
                                 "TranslationYfs": 15,
                                 "NbXfs": 2,
                                 "NbYfs": 1,
                                 "XfsPitch": 20,
                                 "YfsPitch": 0,
                                 "FastenerID for All": True,
                                 "F1_FID": "Fastener",
                                 "F1_X": 30,
                                 "F1_Y": 15,
                                 "F1_HeadSidePart": None,
                                 "F1_Dummy": "No",
                                 "F1_PostProcessing": "Yes",
                                 "F2_FID": "Fastener",
                                 "F2_X": 50,
                                 "F2_Y": 15,
                                 "F2_HeadSidePart": None,
                                 "F2_Dummy": "No",
                                 "F2_PostProcessing": "Yes"}),
    isami.Item("Joint Table", **{"AirbusEO_TJoint": "Joint_Frame-Clip",
                                 "EquallyDistributed": True,
                                 "TranslationXfs": 30,
                                 "TranslationYfs": 60,
                                 "NbXfs": 2,
                                 "NbYfs": 1,
                                 "XfsPitch": 25,
                                 "YfsPitch": 0,
                                 "FastenerID for All": True,
                                 "F1_FID": "Fastener",
                                 "F1_X": 30,
                                 "F1_Y": 60,
                                 "F1_HeadSidePart": None,
                                 "F1_Dummy": "No",
                                 "F1_PostProcessing": "Yes",
                                 "F2_FID": "Fastener",
                                 "F2_X": 55,
                                 "F2_Y": 60,
                                 "F2_HeadSidePart": None,
                                 "F2_Dummy": "No",
                                 "F2_PostProcessing": "Yes"}),
    isami.Item("Frame Table", **{"Frame Name": "Fr-1",
                                 "Profile0": "frame_1",
                                 "Offset Y0": 3,
                                 "Offset Z0": 0,
                                 "Flip Y0": False,
                                 "Flip Z0": False}),
]


@sf.node
def isami_batch(flow_variables: sf.FlowVariables, input_table: pd.DataFrame) -> pd.DataFrame:
    from pprint import pprint
    pprint(flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Generate_Data'])
    doe = DoE.load(flow_variables['doe'], values=input_table)

    project = flow_variables.get('isami_project', "A350-900_ESK_1AIRBUS")
    nb_core = flow_variables.get('isami_nb_core', 32)
    queue = flow_variables.get('isami_queue')
    user_group = flow_variables.get('isami_user_group', "ug_st_std")
    mem_req = flow_variables.get('isami_mem_req', 15000)
    mem_limit = flow_variables.get('isami_mem_limit', 15000)

    # TODO: parameter
    #job_name = flow_variables.get('job_name', "MSP_Z02C_SUMO")
    job_name = flow_variables['job_name']
    isami_version = flow_variables.get('isami_version', "v10.0.0")
    batch_size = flow_variables.get('batch_size', 250)

    output_table = isami.run_batch(doe=doe, items=items, job_name=job_name, project=project,
                                   nb_core=nb_core, queue=queue,
                                   user_group=user_group, isami_version=isami_version,
                                   mem_req=mem_req, mem_limit=mem_limit, batch_size=batch_size)
