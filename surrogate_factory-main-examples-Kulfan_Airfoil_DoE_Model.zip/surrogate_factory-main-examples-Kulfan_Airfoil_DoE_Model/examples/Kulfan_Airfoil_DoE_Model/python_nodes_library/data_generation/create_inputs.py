import sys
import os.path
import pandas as pd
import numpy as np

import surrogate_factory as sf
from surrogate_factory.workflow.doe import DoE
import random


def seed(n: int):
    random.seed(n)
    np.random.seed(n)


@sf.node
def generate(flow_variables):
    doe = DoE.load(flow_variables['doe'])
    output_table = pd.DataFrame(doe.generate(), np.arange(len(doe)))


@sf.node
def create_inputs(flow_variables):

    doe = DoE.load(flow_variables['doe'])
    doe.create_inputs()
    return pd.DataFrame(doe.values(), index=np.arange(len(doe)))  # doe.values(False)


@sf.node
def scale(flow_variables, input_table):
    doe = DoE.load(flow_variables['doe'], input_table)
    doe.scale()
    return pd.DataFrame(doe.values(), index=np.arange(len(doe)))  # doe.values(False)


@sf.node
def extend(flow_variables, input_table):
    doe = DoE.load(flow_variables['doe'], input_table)
    return pd.DataFrame(doe.values(), index=np.arange(len(doe)))  # doe.values(False)


@sf.node
def filter(flow_variables, input_table):
    doe = DoE.load(flow_variables['doe'], input_table)
    doe.extend()
    doe.filter()
    # print(doe.values())
    return pd.DataFrame(doe.values(), index=np.arange(len(doe)))
