from surrogate_factory.workflow.doe import (
    BoundedVariable, Constant, Constraint, CatalogVariable, DependentVariable, DoE, concat_inputs, split, UniqueName, Function)
import numpy as np
import json
from toolz import compose

import surrogate_factory as sf
import sympy as sp


def get_fixed_variables(flow_variables):

    config_params = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Generate_Data']
    airfoils = config_params['fixed_parameters'].get('airfoils')
    fixed_variables = [
        Constant("airfoil", airfoils, column_name="Airfoil Type", sheet_name="Airfoil Table"),]
    return fixed_variables


@sf.node
def define_doe(flow_variables):
    params = flow_variables['metadata', 'Data_acquisition_generation', 'Data_generation', 'Create_Design_of_Experiments']
    # print(params['Design_Space']['constraints'])
    constraints = list(map(compose(Constraint, str.strip), json.loads(params['Design_Space']['constraints'])))

    sheet_var = params['DoE'].get('isami_vars', [])
    # TODO: add profile skin length
    # print(params['Design_Space']['inputs'])
    variables = []
    for input_ in params['Design_Space']['inputs'].values():
        # print(input_)
        name = input_['name']
        sheet = {}
        if name in sheet_var:
            sheet['sheet_name'] = "Airfoil Table"

        if 'equation' in input_:
            func = input_['equation']
            var = DependentVariable(name, func, **sheet)
        elif 'bounds' in input_:
            var = BoundedVariable(name, bounds=eval(input_['bounds']), **sheet)
        elif 'value' in input_:
            var = Constant(name, input_['value'], **sheet)
        elif 'catalog' in input_:
            var = CatalogVariable(name, eval(input_['catalog']), **sheet)
        else:
            raise TypeError(f"Input not recognised: {input_}")

        variables.append(var)
    fixed_variables = get_fixed_variables(flow_variables)
    variables.extend(fixed_variables)

    kwargs = {
        'method': params['DoE']['algorithm'].lower(),
        'experiments': params['DoE']['size'],
        'constraints': constraints,
        'variables': variables,
    }

    flow_variables['doe'] = DoE(**kwargs).dump(json=True)
