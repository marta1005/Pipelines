import sys
import os.path

from surrogate_factory.workflow.doe import DoE
from pathlib import Path
import numpy as np
import pandas as pd
from operator import itemgetter
from typing import Dict, Union
import surrogate_factory as sf

# import json
import csv

import neuralfoil as nf
import aerosandbox as asb
from aerosandbox.geometry.airfoil.airfoil_families import get_NACA_coordinates, get_kulfan_parameters, get_kulfan_coordinates
from aerosandbox.aerodynamics.aero_2D.xfoil import XFoil


def simulation_tool(input_df, flow_variables, xFoil):
    # With xFoil = True xFoil will be used as sim tool via the aerosandbox API.
    # Otherwise, neuralfoil will be used.

    # Convert the input pandas.Dataframe into a numpy array and shuffle contents.
    # Calculate output aerodynamics from airfoil.
    input_np = input_df.to_numpy()
    np.random.shuffle(input_np)
    kulfan_params_list = []
    sim_result_cL = {}
    sim_result_cD = {}
    sim_result_cM = {}
    sim_result_xT = {}
    sim_result_xB = {}
    airfoils = flow_variables["metadata", "Data_acquisition_generation", "Data_generation", "Generate_Data", "fixed_parameters", "airfoils"]
    out_list = []

    if isinstance(airfoils, str):
        airfoil_list = list(map(str.strip, airfoils.strip('[]').split(',')))
        print(len(airfoil_list), len(input_np))

    if len(input_np) % len(airfoil_list) == 0:
        rem = 0

    else:
        div = divmod(len(input_np), len(airfoil_list))
        rem = div[1]

    # else:
        # raise ValueError("Please provide a number of airfoils that is a divisor of the DoE size.")

    offset = np.zeros(len(airfoil_list), dtype=int)
    for rem_idx in range(rem):
        offset[rem_idx] = 1
    # print(split_size, rem, offset)

    for index in range(len(input_np)):
        alpha_raw = input_np[index, 0]
        re_raw = input_np[index, 1]
        LE_weight = input_np[index, 20]
        TE_thick = input_np[index, 21]
        low_weights = []
        up_weights = []

        # Get lower weights from Kulfan parameters.
        for idx in range(8):
            low_weights.append(input_np[index, 4 + idx])

        # Get upper weights from Kulfan parameters.
        for idx in range(8):
            up_weights.append(input_np[index, 12 + idx])

        coordinates = get_kulfan_coordinates(
            lower_weights=low_weights,
            upper_weights=up_weights,
            leading_edge_weight=LE_weight,
            TE_thickness=TE_thick,
            n_points_per_side=8)

        aero = nf.get_aero_from_coordinates(coordinates=coordinates, alpha=alpha_raw, Re=re_raw)

        # Lift coefficient.
        sim_result_cL[index] = aero['CL'].item()
        # Drag coefficient.
        sim_result_cD[index] = aero['CD'].item()
        # Moment coefficient.
        sim_result_cM[index] = aero['CM'].item()
        # Top transition location x/c.
        sim_result_xT[index] = aero['Top_Xtr'].item()
        # Bottom transition location x/c.
        sim_result_xB[index] = aero['Bot_Xtr'].item()

    # Get rid of list of airfoils.
    # Add Kulfan parameters to input_table_1.
    input_df = input_df.drop('airfoil', axis=1)
    input_df = pd.concat([input_df, pd.DataFrame.from_dict(kulfan_params_list, orient='columns')], axis=1, ignore_index=False)

    # Save in format to prepare for parser.
    for i in range(len(input_df)):
        out_dict = {"id": i,
                    "lift_coefficient": sim_result_cL[i],
                    "drag_coefficient": sim_result_cD[i],
                    "moment": sim_result_cM[i],
                    "top_transition_location": sim_result_xT[i],
                    "bot_transition_location": sim_result_xB[i]
                    }
        # Add current values to the list.
        out_list.append(out_dict)

    with open('output.csv', 'w', newline='') as file:
        csv_out = csv.writer(file, quoting=csv.QUOTE_MINIMAL)
        for ddict in out_list:
            csv_out.writerow([ddict])

        # Old parser: create seperate output files.
        # with open(f"output_{i}.json", "w") as file:
        #    json.dump(out_dict, file, indent=4)

    return input_df


def add_noise(airfoil: asb.Airfoil):
    n_weights_per_side = 8

    airfoil_database_path = asb._asb_root / "geometry" / "airfoil" / "airfoil_database"

    UIUC_airfoils = [
        asb.Airfoil(name=filename.stem).normalize()
        for filename in airfoil_database_path.iterdir() if filename.suffix == ".dat"
    ]

    rand_airfoil = lambda: np.random.choice(UIUC_airfoils)

    af: asb.Airfoil = rand_airfoil().blend_with_another_airfoil(
        rand_airfoil(),
        blend_fraction=np.random.rand()
    ).blend_with_another_airfoil(
        rand_airfoil(),
        blend_fraction=np.random.rand()
    )

    af = af.scale(1, np.random.lognormal(0, 0.15))

    kulfan_params = get_kulfan_parameters(
        coordinates=af.normalize().coordinates,
        n_weights_per_side=n_weights_per_side,
    )

    deviance = np.random.exponential(0.05)
    kulfan_params["lower_weights"] += np.random.randn(n_weights_per_side) * deviance
    kulfan_params["upper_weights"] += np.random.randn(n_weights_per_side) * deviance
    kulfan_params["leading_edge_weight"] += np.random.randn() * deviance
    kulfan_params["TE_thickness"] += np.random.exponential(0.003)

    if np.random.rand() < 0.5:
        kulfan_params["TE_thickness"] = 0

    if np.random.rand() < 0.75:
        if np.random.rand() < 0.5:
            kulfan_params["lower_weights"][0] = -kulfan_params["upper_weights"][0]
        else:
            kulfan_params["upper_weights"][0] = -kulfan_params["lower_weights"][0]

    af = asb.Airfoil(
        name="Reconstructed Airfoil",
        coordinates=nf.get_kulfan_coordinates(
            **kulfan_params
        )
    )

    return af.blend_with_another_airfoil(airfoil)


@sf.node
def launch_sim(flow_variables: sf.FlowVariables, input_table: pd.DataFrame, xFoil: bool) -> pd.DataFrame:
    """
    This function will execute the Simulation tool with the Input_table provided to generate the Output results
    """

    input_table_edit = simulation_tool(input_table, flow_variables, xFoil)

    return input_table_edit
