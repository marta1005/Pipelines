from surrogate_factory.workflow.doe import DoE, SympyFunction
import numpy as np
import surrogate_factory as sf


@sf.node
def gather_inputs(flow_variables, input_table):
    doe = DoE.load(flow_variables['doe'])
    return input_table[doe.model_vars()]


@sf.node
def add_features(flow_variables, input_table):

    # new_outputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'new_outputs']
    new_inputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'new_inputs']

    for input_ in new_inputs.values():
        print(input_)
        name = input_['name']
        equation = SympyFunction(input_['equation'])
        input_table[name] = equation(input_table)

    inputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'inputs']
    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))

    outputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'outputs']
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))

    variables = inputs + outputs
    print(variables)
    return input_table[variables]
