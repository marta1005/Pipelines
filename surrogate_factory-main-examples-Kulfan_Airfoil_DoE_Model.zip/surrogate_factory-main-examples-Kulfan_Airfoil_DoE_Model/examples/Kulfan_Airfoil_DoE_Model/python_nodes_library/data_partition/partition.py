import numpy as np
import pandas as pd
import surrogate_factory as sf

import pickle
import os

@sf.node
def data_split(flow_variables, input_table):
    """_summary_
    Function to split data in the 3 datasets for training, test and validation
    flow_variables should be updated accordingly
    Args:
        flow_variables (_type_): flow_variables of the pipeline 
        input_table (_type_): Dataset to split

    Returns:
        Train_set: pandas DataFrame
        Test_set: pandas DataFrame
        Val_set: pandas DataFrame

    """
    from sklearn.model_selection import train_test_split

    train_perc = flow_variables["metadata", "Data_Partition", "percentages", "train"]
    test_perc = flow_variables["metadata", "Data_Partition", "percentages", "test"]
    validation_perc = flow_variables["metadata", "Data_Partition", "percentages", "validation"]

    Train_set_, Val_set = train_test_split(
        input_table,
        test_size=validation_perc, random_state=42, shuffle=True)

    Train_set, Test_set = train_test_split(
        Train_set_, test_size=test_perc, random_state=42, shuffle=True)

    flow_variables['metadata', 'Data_Partition', 'size', 'train'] = Train_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'test'] = Test_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'validation'] = Val_set.shape[0]   

    return Train_set, Test_set, Val_set
