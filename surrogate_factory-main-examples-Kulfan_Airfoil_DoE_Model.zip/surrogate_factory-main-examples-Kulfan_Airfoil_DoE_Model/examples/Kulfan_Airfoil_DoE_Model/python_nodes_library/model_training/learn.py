import pandas as pd
import numpy as np

from pathlib import Path
from collections import UserDict

import surrogate_factory as sf
from surrogate_factory import nodes

import torch
from torch.utils.data import TensorDataset, DataLoader

# Always import new models here, do not edit surrogate factory code.
from sklearn.kernel_ridge import KernelRidge
from sklearn.neural_network import MLPRegressor
from model_training.neural_network import Net


@sf.node
def get_custom_model(algorithm: UserDict):
    # Use this to differentiate if more models get added.
    # Read model name and parameters defined in Excel file "Model_Selection".
    # If a key is missing, provide default values.
    model_name = algorithm['algorithm']
    params = algorithm['settings']

    if model_name == 'KernelRidge':
        alpha = params.get('alpha', 1)
        kernel = params.get('kernel', 'linear')
        gamma = params.get('gamma', None)
        degree = params.get('degree', 3)
        coef0 = params.get('coef0', 1)
        kernel_params = params.get('kernel_params', None)

        model = KernelRidge(alpha=alpha, kernel=kernel, gamma=gamma, degree=degree, coef0=coef0, kernel_params=kernel_params)

    if model_name == 'MLPRegressor':
        activation = params.get('activation', 'relu')
        early_stopping = params.get('early_stopping', True)
        hidden_layer_sizes = params.get('hidden_layer_sizes', '(128, 128)')
        max_iter = params.get('max_iter', 10000)
        solver = params.get('solver', 'adam')
        validation_fraction = params.get('validation_fraction', 0.15)
        learning_rate = params.get('learning_rate', 'adaptive')
        learning_rate_init = params.get('learning_rate_init', 0.001)
        batch_size = params.get('batch_size', 'auto')

        model = MLPRegressor(activation=activation, alpha=1e-04, batch_size=batch_size, beta_1=0.9,
                             beta_2=0.999, early_stopping=early_stopping, epsilon=1e-08,
                             hidden_layer_sizes=eval(hidden_layer_sizes), learning_rate=learning_rate,
                             learning_rate_init=learning_rate_init, max_fun=15000, max_iter=max_iter,
                             momentum=0.9, n_iter_no_change=10, nesterovs_momentum=True,
                             power_t=0.5, random_state=33, shuffle=True, solver=solver,
                             tol=0.0001, validation_fraction=validation_fraction, verbose=False, warm_start=False)

    if model_name == 'neuralfoil':
        model = Net().to(torch.device('cpu'))

    return model


@sf.node
def train(flow_variables: sf.FlowVariables, Train_set: pd.DataFrame, Val_set: pd.DataFrame, outputs_cols=None):
    """
    Function to train models.
    Args:
        flow_variables (sf.FlowVariables): our metadata dict
        input_table_1 (pd.DataFrame): train data
        scaler (_type_): scaler fitted to be applied to our data
    Requeriments:
        Use MLFlow to track your model
    Returns:
        a model fitted
        Models has to be saved and path to files added in the metadata accordingly.
        Models files will be used by next functions and notebooks in the pipeline
    """
    # experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']

    inputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "inputs"]
    outputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "outputs"]

    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))
    if outputs_cols is not None:
        outputs = outputs_cols

    Train_X = Train_set[inputs]
    Train_Y = Train_set[outputs]
    Val_X = Val_set[inputs]
    Val_Y = Val_set[outputs]

    # This is an example.
    job_name = flow_variables['job_name']
    flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name'] = job_name

    tracker = nodes.get_tracker(flow_variables)

    models = {}
    for algorithm in flow_variables['metadata', 'Model_Selection', 'algorithms'].values():

        model = get_custom_model(algorithm)

        run_id = tracker.start_tracker(flow_variables, algorithm)

        # Preprocess.

        for scaler in flow_variables['metadata', 'Feature_selection', 'preprocess'].values():
            print(f"{scaler['method']} for output {scaler['output']}.")
            if scaler['output'] == algorithm['output']:
                scaler_path = scaler['file']
                print(f"Scaler path: {scaler_path}")

        # Load scaler from file path and transform Train and Validation Input Sets.
        import joblib
        scaler = joblib.load(scaler_path)
        input_train_scaled = pd.DataFrame(scaler.transform(Train_X), columns=scaler.get_feature_names_out())
        input_val_scaled = pd.DataFrame(scaler.transform(Val_X), columns=scaler.get_feature_names_out())

        # Fit model.
        # SF core contains a set of models available. You can use them or use your own model if the integration doesn't fit your need.

        model_name = algorithm['algorithm']
        print(f"Model Selected: {model_name}")

        if model_name == 'neuralfoil':
            # Set up model.
            device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
            cache_file = Path(__file__).parent / "nn-xxxlarge.pth"
            print(device)

            net = Net().to(device)

            try:
                net.load_state_dict(torch.load(cache_file))
                print("Model found, resuming training.")
            except FileNotFoundError:
                print("No existing model found, starting fresh.")

            # Define the optimizer
            learning_rate = 1e-4
            optimizer = torch.optim.RAdam(net.parameters(), lr=learning_rate, weight_decay=1e-5)
            scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                optimizer,
                factor=0.5,
                patience=20,
                verbose=True,
                min_lr=1e-6,
            )

            loss_weights = torch.tensor(list({
                "CL": 1,
                "ln_CD + 4": 1,
                "CM * 20": 0.25,
                "u_max_over_u": 0.25,
                "Top_Xtr": 0.25,
                "Bot_Xtr": 0.25,
            }.values())).reshape(1, -1)

            # Define the data loader
            print("Preparing data...")

            batch_size = 512
            train_inputs = torch.tensor(
                input_train_scaled.to_numpy(),
                dtype=torch.float32,
            )
            train_outputs = torch.tensor(
                Train_Y.to_numpy(),
                dtype=torch.float32,
            )
            train_loader = DataLoader(
                dataset=TensorDataset(train_inputs, train_outputs),
                batch_size=batch_size,
                shuffle=True,
                num_workers=16,
            )

            test_inputs = torch.tensor(
                input_val_scaled.to_numpy(),
                dtype=torch.float32,
            )
            test_outputs = torch.tensor(
                Val_Y.to_numpy(),
                dtype=torch.float32,
            )
            test_loader = DataLoader(
                dataset=TensorDataset(test_inputs, test_outputs),
                batch_size=65536,
                num_workers=16,
            )

            # raise Exception
            print("Training...")

            # n_batches_per_epoch = len(train_loader)
            loss_weights = loss_weights.to(device)

            num_epochs = 10000
            for epoch in range(num_epochs):

                # Train the model
                net.train()

                batch_losses = []

                for i, (x, y) in enumerate(train_loader):

                    x = x.to(device)
                    y = y.to(device)

                    y_pred = net(x)

                    loss = torch.mean(loss_weights * (y_pred - y) ** 2)
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    batch_losses.append(loss.item())

                train_loss = np.mean(batch_losses)

                # Evaluate the model
                net.eval()

                batch_losses = []
                batch_residual_mae = []  # Residual mean absolute error (MAE, L1 norm) of each test batch

                for i, (x, y) in enumerate(test_loader):
                    with torch.no_grad():
                        x = x.to(device)
                        y = y.to(device)

                        y_pred = net(x)

                        batch_losses.append(
                            torch.mean(loss_weights * (y_pred - y) ** 2).item()
                        )
                        batch_residual_mae.append(
                            torch.mean(torch.abs(y_pred - y), dim=0).cpu().numpy()
                        )

                test_loss = np.mean(batch_losses)
                test_residual_mae = np.mean(np.stack(batch_residual_mae, axis=0), axis=0)

                labeled_maes = {
                    "CL": test_residual_mae[0],
                    "ln_CD": test_residual_mae[1],
                    "CM": test_residual_mae[2] / 20,
                    "u_max_over_u": test_residual_mae[3] * 2,
                    "Top_Xtr": test_residual_mae[4],
                    "Bot_Xtr": test_residual_mae[5],
                }
                print(
                    f"Epoch: {epoch} | Train Loss: {train_loss.item():.6g} | Test Loss: {test_loss.item():.6g} | " + " | ".join(
                        [
                            f"{k}: {v:.6g}"
                            for k, v in labeled_maes.items()
                        ]))

                scheduler.step(train_loss)

                # Save torch model.
                torch.save(net.state_dict(), cache_file)

        else:
            model.fit(input_train_scaled, Train_Y)

        models[algorithm['output']] = model

        # Models has to be saved and path to files added in the metadata accordingly.
        # Models files will be used by next functions and notebooks in the pipeline.
        models_path = Path(flow_variables['data.folder'], 'models')
        models_path.mkdir(exist_ok=True)
        model_file = str(models_path / f"model_{flow_variables['job_name']}_{run_id}.modl")
        joblib.dump(models[algorithm['output']], model_file)
        flow_variables['metadata', 'Model_Training', 'Models', algorithm['output']] = str(model_file)

        tracker.stop_tracker(flow_variables, 'RUNNING')

    return models
