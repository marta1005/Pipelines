import mlflow
import surrogate_factory as sf


@sf.node
def create_final_run(flow_variables):
    experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']
    experiment = mlflow.set_experiment(experiment_name)

    with mlflow.start_run():
        tracking = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval']

        metrics = {}
        for k, v in tracking.items():
            if 'metrics' in v:
                metrics.update({f"{k}_{name}": val
                                for name, val in v['metrics'].items()
                                if val is not None})

        run = mlflow.active_run()
        flow_variables['metadata', 'hashcode'] = run.info.run_id

        mlflow.log_metrics(metrics)

