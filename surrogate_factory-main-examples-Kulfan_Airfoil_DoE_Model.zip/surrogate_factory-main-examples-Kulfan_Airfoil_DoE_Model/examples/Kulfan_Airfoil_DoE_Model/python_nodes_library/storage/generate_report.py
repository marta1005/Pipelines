import mlflow
from datetime import datetime
import surrogate_factory as sf
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch, cm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Image, Table, TableStyle

styles = getSampleStyleSheet()
width = 595.27
height = 841.89
pagesize = (width, height)


def cover_page(canvas: Canvas, doc):
    title = 'Report'
    dat = datetime.today().strftime('%d-%m-%Y')
    canvas.saveState()
    canvas.setFont('Times-Roman', 18)
    canvas.drawCentredString(width/2.0, height-108, title)
    canvas.setFont('Times-Roman', 9)
    canvas.drawString(inch, 0.75*inch, dat)
    canvas.restoreState()


def doc_pages(canvas: Canvas, doc):
    canvas.saveState()
    canvas.setFont('Times-Roman', 9)
    canvas.drawString(inch, 0.75*inch, 'Page %d' % doc.page)
    canvas.restoreState()


@sf.node
def generate_pdf(flow_variables):

    # Get necessary (meta)data from pipeline json file.
    input = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'inputs']
    output = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']
    algorithm = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'algorithm', 'algorithm']
    run_id = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'run_id']
    metrics = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', f'{output}', 'metrics']
    path = flow_variables['data.folder']

    # Get images.
    deviation_plot = str(f'{path}/img/deviation_plots.png')

    # Create pdf from basic template.
    doc = SimpleDocTemplate(filename=f'report/Report_{run_id}.pdf')
    Story = [Spacer(1, 2*inch)]

    # Normal, left-aligned text.
    style = styles['Normal']
    style.alignment = 0

    # Normal, center-aligned text.
    center_style = styles['Normal']
    center_style.alignment = 1

    # Title text.
    title_style = styles['Heading1']

    # Add paragraph for the front page.
    description = ('<b>Surrogate Factory Pipeline</b> <br/>'
                   '<br/>'
                   f'Experiment: {experiment_name} <br/>'
                   f'Algorithm: {algorithm}')
    front = Paragraph(description, center_style)
    Story.append(front)
    Story.append(Spacer(1, 0.2*inch))
    Story.append(PageBreak())

    # Paragraphs for the second page.
    # Model information.
    info_title = Paragraph('1 Model information', title_style)
    Story.append(info_title)
    Story.append(Spacer(1, 0.2*inch))

    # Inputs and Outputs.
    info_string = ('<b>Inputs</b> <br/>'
                   f'{input} <br/>'
                   '<br/>'
                   '<b>Outputs</b> <br/>'
                   f'{output}')
    info = Paragraph(info_string)
    Story.append(info)
    Story.append(Spacer(1, 0.2*inch))

    # Model settings.
    setting_string = ('<b>Settings</b> <br/>'
                      '<br/>'
                      'Relevant model settings.')
    setting = Paragraph(setting_string)
    Story.append(setting)
    Story.append(Spacer(1, 0.2*inch))
    Story.append(PageBreak())

    # Paragraphs for the third page.
    valid_title = Paragraph('2 Model validation', title_style)
    Story.append(valid_title)
    Story.append(Spacer(1, 0.2*inch))
    v = Paragraph('<b>Metrics</b>')
    Story.append(v)
    Story.append(Spacer(1, 0.2*inch))

    # Create list for metrics table.
    data = []
    for key, val in metrics.items():
        entry = [key, val]
        data.append(entry)

    metrics_table = Table(data)
    metrics_table.setStyle(TableStyle([('INNERGRID', (0, 0), (-1, -1), 0.25, (0, 0, 0)),
                                       ('BOX', (0, 0), (-1, -1), 0.25, (0, 0, 0))]))
    metrics_table.hAlign = 'LEFT'
    Story.append(metrics_table)
    Story.append(Spacer(1, 0.6*inch))
    p = Paragraph('<b>Deviation of prediction values</b>')
    Story.append(p)
    Story.append(Spacer(1, 0.2*inch))

    # Add image.
    i = Image(deviation_plot, width=4.8*inch, height=5.3*inch)
    i.hAlign = 'LEFT'
    Story.append(i)
    Story.append(PageBreak())

    # Build pdf with defined layouts.
    doc.build(Story, onFirstPage=cover_page, onLaterPages=doc_pages)
