import os
import logging
import sys
from pandas import DataFrame
import random
import warnings
import numpy as np
import logging

from pathlib import Path
import surrogate_factory as sf

import mlflow
import shutil
import sklearn
import joblib

import torch


def _get_outdir(flow_variables: sf.FlowVariables, clean=False) -> Path:
    job_name = flow_variables['job_name']
    jobdir = Path(job_name)

    outdir = jobdir / ("models-cwrapper-" + job_name)
    outdir = outdir.resolve()
    if outdir.exists() and clean:
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    return outdir


def get_conda():
    import sklearn
    import orjson
    conda_env = mlflow.pyfunc.get_default_conda_env()
    conda_env['dependencies'][2]['pip'].append(f"scikit-learn=={sklearn.__version__}")
    conda_env['dependencies'][2]['pip'].append(f"orjson=={orjson.__version__}")

    return conda_env


@sf.node
def model_deployment(flow_variables, Dataset):
    """Prepare model for deployment.

    Args:
        flow_variables (_type_): _description_
        Dataset (_type_): _description_

    Returns:
        _type_: _description_
    """

    # not implemented in this example

    return flow_variables


@sf.node
def upload_model(flow_variables):
    """Upload model wrapper

    Args:
        flow_variables (_type_): _description_
    """

    # not implemented in this example

    return flow_variables


@sf.node
def export_model(flow_variables):
    path = Path(flow_variables["data.folder"], "models")

    for model_output in flow_variables['metadata', 'Model_Training', 'Models'].keys():
        # model_path = flow_variables['metadata', 'Model_Training', 'Models', model_output]
        run_id = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', model_output]
        # model = joblib.load(model_path)
        # onnx_pro = torch.onnx.export(model)
        # onnx_pro.save(path + "/" + f"model_{flow_variables['job_name']}_{run_id}.onnx")

    print(f'Model {model_output}_{run_id} saved to {path}.')
