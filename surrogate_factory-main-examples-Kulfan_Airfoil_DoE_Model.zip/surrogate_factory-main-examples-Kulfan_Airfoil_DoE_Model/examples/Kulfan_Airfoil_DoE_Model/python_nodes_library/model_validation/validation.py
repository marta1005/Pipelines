import surrogate_factory as sf


@sf.node
def validate(flow_variables, metrics):
    """This function check metrics of the models with requirements

    Args:
        flow_variables (_type_): _description_
        metrics (_type_): _description_

    Returns:
        _type_: Flow_variables Model_Validation updated
    """
    accuracy_metrics = flow_variables['metadata', 'Requirements', 'accuracy']

    for metric in accuracy_metrics.values():
        metric_name = metric['metric']
        try:
            flow_variables['metadata', 'Model_Validation', metric_name] = str((metrics[metric_name].values > metric['value']).any())
        except KeyError:
            print(f"metric: {metric_name} not computed")
            flow_variables['metadata', 'Model_Validation', metric_name] = str(False)

    return flow_variables
