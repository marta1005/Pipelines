from pathlib import Path
import surrogate_factory as sf
import isami
import mlflow
from matplotlib import pyplot as plt


@sf.node
def plot(flow_variables, input_table):

    for RF in input_table['output'].unique():
        if RF not in ["BucklingType", "Failure_mode"]:
        # index_filter = input_table[(input_table['output']==RF)&(input_table['y_pred']<10)&(input_table['y_pred']>0.1)].index
            index_filter = input_table[(input_table['output']==RF)].index
            y_pred = input_table.loc[index_filter][['y_pred']].copy()
            y_test = input_table.loc[index_filter][['y_test']].copy()
            ratio = input_table.loc[index_filter][['ratio']].copy()

            # column_name = flow_variables['currentColumnName']
            outdir = Path(flow_variables['data.folder'])
            outfile = outdir / (RF + ".pdf")
            outfile_png = outdir / (RF + ".png")
            fig = isami.create_plot(y_pred, y_test, outfile, outfile_png)
            # fig.show()
            fig.add_subplot(3,1,1)
            # plt.subplots(figsize=(20,10))
            plt.scatter(x=y_test, y=ratio) #, s=1
            plt.title('ratio')
            plt.ylabel('ratio')
            plt.xlabel('y_test')
            #plt.legend(['train', 'val'], loc='upper left')
            plt.show()
            plt.savefig(f"ratio_{RF}.png")
        

        # with mlflow.start_run(run_id=flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', RF, 'run_id']):
        #     mlflow.log_artifact(outfile, "graph")
        #     #mlflow.log_artifact(outfile_png, "graph")
        #     mlflow.log_figure(fig, Path(f"{RF}.png"))
