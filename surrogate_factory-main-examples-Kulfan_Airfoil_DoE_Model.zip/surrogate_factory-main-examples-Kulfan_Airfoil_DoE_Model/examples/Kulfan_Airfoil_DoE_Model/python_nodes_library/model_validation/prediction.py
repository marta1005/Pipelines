import pickle
import numpy as np
import time
from pathlib import Path
import pandas as pd
import surrogate_factory as sf
import sympy as sp
from cytoolz import compose
from tensorflow import keras
# from .learn import r_square

import isami
import joblib


def descale(x: np.array, x_min: float, x_max: float):
    """ descale the x variable from its bounds """
    return (x - x_min) / (x_max - x_min)


def test_margin(norm_x: np.array, x_min: float = 0.05, x_max: float = 0.95):
    """ return True if norm_x is betweet x_min and x_max """
    return (norm_x >= x_min) & (norm_x <= x_max)


@sf.node
def prediction_resnet(flow_variables, input_table, preprocess_fit, postprocess_fit):
    """
    calculate test predictions with the current model, excluding values within
    a margin of 20% for geometric variables and 10% for phi and theta.
    """
    name = flow_variables['currentColumnName']

    # from sympy.abc import x
    # defeature = sp.lambdify(x, defeature_obj)
    input_table.dropna(inplace=True)
    test = input_table[[name]]
    test.columns = ['y_test']

    input_cols = [c for c in input_table.columns
                  if c != name]
    # input_cols_set = set(input_cols)

    # dinputs = flow_variables['metadata', 'Data_acquisition_generation',
    #                          'Data_generation', 'Create_Design_of_Experiments',
    #                          'Design_Space', 'inputs'].copy()

    # #dinputs = {d.pop('name'): d for d in dinputs.values()}
    # dinputs = {d['name']: d for d in dinputs.values()}
    # print(dinputs)
    # input_cols_set = dinputs.keys()

    # N0 = dinputs['N0']['value']
    # #b = input_table['b']
    # try:
    #     Nyy = input_table['Nyy']
    # except KeyError:
    #     Nyy = 0.0
    # Nxy = input_table['Nxy']

    # # Nyy = N0 * sin(phi)
    # phi = np.arcsin(Nyy / N0)
    # # Nxy = N0 * cos(theta) * cos(phi)
    # theta = np.arccos(Nxy / (N0 * np.cos(phi)))

    # try:
    #     phi_bounds = dinputs['phi']['bounds']
    # except KeyError:
    #     phi_bounds = [0.0, 0.0]
    # if isinstance(phi_bounds, str):
    #     phi_bounds = map(compose(float, str.strip), phi_bounds.strip('[]').split(','))

    # phi_min, phi_max = phi_bounds

    # theta_bounds = dinputs['theta']['bounds']
    # if isinstance(theta_bounds, str):
    #     theta_bounds = map(compose(float, str.strip), theta_bounds.strip('[]').split(','))

    # theta_min, theta_max = theta_bounds

    # # normalised phi and theta
    # norm_phi = descale(phi, phi_min, phi_max)
    # norm_theta = descale(theta, theta_min, theta_max)

    # load_min, load_max = 0.0, 1.0
    # load_midmax, load_midmin = 0.5, 0.5
    # # apply margin to phi and theta
    # test_samples = ((test_margin(norm_phi, load_min, load_max)) &
    #                 (test_margin(norm_theta, load_min, load_midmax) | test_margin(norm_theta, load_midmin, load_max)))

    # f_cols = {'Nx', 'Nxy', 'Nyy',  'Nxx'}
    # geom_cols = input_cols_set - f_cols
    # print("geometric varibles:", geom_cols)

    # # apply margin to geometric variables
    # norm_min, norm_max = 0.00, 1.00
    # for c in geom_cols:
    #     print("geo cols:", c)
    #     x = input_table[c]
    #     x_bounds = dinputs[c]['bounds']
    #     if isinstance(x_bounds, str):
    #         x_bounds = map(compose(float, str.strip), x_bounds.strip('[]').split(','))

    #     x_min, x_max = x_bounds
    #     norm_x = descale(x, x_min, x_max)
    #     test_samples += test_margin(norm_x, norm_min, norm_max)

    # predictions
    inputs = input_table[input_cols]#.loc[test_samples]
    # print("predict debug")
    # print(test_samples)
    # print(inputs)
    inputs = pd.DataFrame(preprocess_fit[name].transform(inputs), columns=inputs.columns, index=inputs.index)

    run_id = flow_variables['metadata', 'Model_Training', 'Tracking',
                            'eval', name, 'run_id']

    experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']
    workdir = Path(experiment_name)
    out_dir = workdir / ("models-" + experiment_name)
    run_name = flow_variables['currentColumnName']
    model_filename = flow_variables['metadata', 'Model_Training', 'Models', flow_variables['currentColumnName']]# flow_variables['metadata', 'Model_Training', 'model_name']
    # model_filename = Path(model_name).resolve()
    # model_filename = Path(flow_variables["data.folder"],flow_variables["job_name"], "models", f"{run_id}_{run_name}")
    deps = {'r_square': r_square}

    model = keras.models.load_model(str(model_filename), compile=False)
    pred = pd.DataFrame(model.predict(inputs, batch_size = 1024),
                        index=inputs.index,
                        columns=[name])

    if postprocess_fit[name]['type'] == "pandas":
        outputs = pred.eval(postprocess_fit[name]['formula'])

    outputs.rename(columns={name: "y_pred"}, inplace=True)
    print(outputs.join(test, how='inner'))
    return outputs.join(test, how='inner')#.applymap(defeature)


@sf.node
def prediction_mlpc(flow_variables, input_table, preprocess_fit, postprocess_fit):
    """
    calculate test predictions with the current model, excluding values within
    a margin of 20% for geometric variables and 10% for phi and theta.
    """

    name = flow_variables['currentColumnName']

    # from sympy.abc import x
    # defeature = sp.lambdify(x, defeature_obj)
    input_table.dropna(inplace=True)
    test = input_table[[name]]
    test.columns = ['y_test']

    input_cols = [c for c in input_table.columns
                  if c != name]

    # predictions
    inputs = input_table[input_cols]#.loc[test_samples]

    inputs = pd.DataFrame(preprocess_fit[name].transform(inputs), columns=inputs.columns, index=inputs.index)

    run_id = flow_variables['metadata', 'Model_Training', 'Tracking',
                            'eval', name, 'run_id']

    experiment_name = flow_variables['metadata', 'Model_Training', 'Tracking', 'experiment_name']
    workdir = Path(experiment_name)
    out_dir = workdir / ("models-" + experiment_name)
    run_name = flow_variables['currentColumnName']
    model_name = flow_variables['metadata', 'Model_Training', 'Models', flow_variables['currentColumnName']]# flow_variables['metadata', 'Model_Training', 'model_name']
    model_filename = flow_variables['metadata', 'Model_Training', 'Models', flow_variables['currentColumnName']]# flow_variables['metadata', 'Model_Training', 'model_name']
    deps = {'r_square': r_square}

    model = joblib.load(model_name)
    pred = pd.DataFrame(model.predict(inputs),
                        index=inputs.index,
                        columns=[name])
    print("pred", pred)

    if postprocess_fit[name]['type'] == "pandas":
        outputs = pred.eval(postprocess_fit[name]['formula'])
    outputs.rename(columns={name: "y_pred"}, inplace=True)

    return outputs.join(test, how='inner')#.applymap(defeature)


@sf.node
def predict(flow_variables, input_table, outputs_cols=None) -> pd.DataFrame:
    """This function will execute the preprocessor, model, postprocessor to compute the output

    Args:
        flow_variables (_type_): _description_
        input_table (_type_): _description_
        outputs_cols (_type_, optional): _description_. Defaults to None.

    Returns:
        pd.DataFrame: a Dataframe containing each output in rows. [y_pred, y_test, output_name]
    """

    output_table = pd.DataFrame()

    inputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "inputs"]
    outputs = flow_variables["metadata", "Feature_selection", "Add_remove_features", "outputs"]
    outputs_str = outputs

    # Get inputs and outputs for prediction, multiple choices possible.
    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))
    if outputs_cols is not None:
        outputs = outputs_cols

    # Predict values for all selected outputs.
    print('prediction for', outputs, 'from', inputs)
    output_table_1 = pd.DataFrame()

    # Get path from json file.
    model_name = flow_variables['metadata', 'Model_Training', 'Models', outputs_str]

    # Load model from path.
    model = joblib.load(model_name)
    output_table_1 = input_table[inputs].copy()

    # Preprocessor.
    # Load scaler from file path and transform Test Set.
    for scaler in flow_variables['metadata', 'Feature_selection', 'preprocess'].values():
        if scaler['output'] == outputs_str:
            scaler_path = scaler['file']

    scaler = joblib.load(scaler_path)
    input_test_scaled = pd.DataFrame(scaler.transform(output_table_1), columns=scaler.get_feature_names_out())
    # End preprocessor.

    # Add model predict here.
    pred_array = model.predict(input_test_scaled)
    # End model predict.

    # Add postprocessor here if needed.

    # End postprocessor.

    for index, out in enumerate(outputs):

        # df = input_table[inputs+[out]]

        output_table_1[f'y_pred_{out}'] = pd.DataFrame(pred_array[:, index], columns=[f'y_pred_{index}'])

        output_table_1[f'y_test_{out}'] = input_table[[out]]
        # output_table_1[f'output_{index}'] = out

    output_table = pd.concat([output_table, output_table_1], ignore_index=True)

    return output_table
