import mlflow
import surrogate_factory as sf
import numpy.linalg as lin
import sklearn.metrics as skm
import mlflow
import numpy as np
import pandas as pd
from functools import partial
from cytoolz.curried import valfilter, complement
from cytoolz.curried.operator import is_
import keras.backend as K

from surrogate_factory import nodes

# metrics available in adatools
# from loss_keras import loss_KDF_v4, KDF_accuracy, KDF_accuracy_v2, centerflow_variables


from sklearn.metrics import confusion_matrix


def compute_confusion_matrix(y_pred, y_test):
    """Compute confusion matrix score

    Args:
        y_pred (_type_): _description_
        y_test (_type_): _description_

    Returns:
        _type_: _description_
    """
    cm = confusion_matrix(y_pred, y_test)
    accuracy = np.trace(cm) / np.sum(cm).astype('float')
    # misclass = 1 - accuracy
    metric = {"confusion_matrix": accuracy}
    return metric


# @sf.node
def compute_metrics(y_pred, y_test):
    """Common metrics available
    Args:
        y_pred (_type_): _description_
        y_test (_type_): _description_

    Returns:
        _type_: _description_
    """

    y_diff = np.abs(np.array(y_pred) - np.array(y_test)) / (np.array(y_test) + 0.01)
    y_diff_sort = np.sort(a=y_diff, axis=None)

    quantile90, quantile95, quantile99 = np.quantile(y_diff_sort, [0.9, 0.95, 0.99])
    # lstsq = lin.lstsq(y_test, y_pred)[0][0]

    skmetrics = {
        'explained_variance': skm.explained_variance_score,
        'max_error': skm.max_error,
        'mean_absolute_error': skm.mean_absolute_error,
        'rmse': partial(skm.mean_squared_error, squared=False),
        'R2': skm.r2_score,
        'mean_absolute_percentage_error': skm.mean_absolute_percentage_error,
    }

    metrics = {
        'quantile90': quantile90,
        'quantile95': quantile95,
        'quantile99': quantile99,
        # 'lstsq': lstsq,
    }

    for key, func in skmetrics.items():
        try:
            metrics[key] = func(y_test, y_pred)
            # print(key, func)
        except Exception as err:
            print(err)
            metrics[key] = None

    return metrics


@sf.node
def calculate_metrics(flow_variables, input_table, log_mlflow = True):
    """Compute the metrics of the models

    Args:
        flow_variables (_type_): _description_
        input_table (_type_): _description_
        log_mlflow (bool, optional): _description_. Defaults to True.

    Returns:
        metrics_df: pandas DataFrame containing the metrics of each output
    """
    metrics_df = pd.DataFrame()

    # tracker = nodes.get_tracker(flow_variables)

    outputs_str = flow_variables["metadata", "Feature_selection", "Add_remove_features", "outputs"]
    if isinstance(outputs_str, str):
        outputs = list(map(str.strip, outputs_str.strip('[]').split(',')))

    for idx, out in enumerate(outputs):

        metrics = {}

        ypred = input_table[f'y_pred_{out}'].copy()
        ytest = input_table[f'y_test_{out}'].copy()

        # When using a classifier.
        # metrics = compute_confusion_matrix(ypred, ytest)

        metrics = compute_metrics(ypred, ytest)
        print(metrics)

        # cname = flow_variables['currentColumnName']
        flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', outputs_str, 'metrics'] = metrics
        # run_id = flow_variables['metadata', 'Model_Training', 'Tracking', 'eval', outputs_str, 'run_id']
        # if log_mlflow:
        #     tracker.log(run_id, metrics)

        # metrics_df = metrics_df.append(metrics, ignore_index=True) deprecated in pandas 2.0
        # print(pd.DataFrame.from_dict(metrics, orient='index'))

        # Prepare pandas DataFrame as return value.
        metrics_df = pd.concat([metrics_df, pd.DataFrame(metrics, index=[0])], ignore_index=True)
    metrics_df.index = ['lift_coefficient', 'drag_coefficient', 'moment', 'top_transition_location', 'bot_transition_location']

    # worst_airfoils = low_metrics(metrics_df, 10)

    # TODO: visualize (also export/store in json?)
    # print(worst_airfoils)

    return metrics_df


@sf.node
def low_metrics(metrics, length):
    # Find number of x = length worst performing airfoils.
    low_list = []

    # Pick lowest scoring models.
    # For this example based off of the max_error metric.
    # Sort after highest value and pick the top N = length items.
    max_error_sorted = metrics[5].values().sort(reverse = True)
    low_list.append(max_error_sorted[:length])

    return low_list
