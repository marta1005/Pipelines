from datetime import datetime
import sys
import os.path
import json
import csv

from surrogate_factory.workflow.doe import DoE

import numpy as np
import pandas as pd
import json
import cProfile as profile
import io
import pstats
from cytoolz.curried import flip
import surrogate_factory as sf


@sf.node
def batch_extract(flow_variables, input_table) -> pd.DataFrame:
    """Extract function

    Args:
        flow_variables (_type_): _description_
        input_table (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """
    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']

    parsed_output = pd.DataFrame()
    with open('output.csv', 'r', newline = '') as file:
        csv_read = csv.reader(file)
        for row in csv_read:
            row = ', '.join(row)
            json_row = row.replace("'", "\"")
            output = json.loads(json_row)
            parsed_output.loc[output['id'], 'lift_coefficient'] = output['lift_coefficient']
            parsed_output.loc[output['id'], 'drag_coefficient'] = output['drag_coefficient']
            parsed_output.loc[output['id'], 'moment'] = output['moment']
            parsed_output.loc[output['id'], 'top_transition_location'] = output['top_transition_location']
            parsed_output.loc[output['id'], 'bot_transition_location'] = output['bot_transition_location']

    return parsed_output


@sf.node
def batch_transform(flow_variables, parsed_batches) -> pd.DataFrame:
    """ Transform function
        nothing to do in this example
    Args:
        flow_variables (_type_): _description_
        parsed_batches (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """
    transformed_batches = parsed_batches.copy()
    return transformed_batches


@sf.node
def batch_load(flow_variables, transformed_batches, input_table) -> pd.DataFrame:
    """_summary_

    Args:
        flow_variables (_type_): _description_
        transformed_batches (_type_): _description_
        input_table (_type_): _description_

    Returns:
        pd.DataFrame: _description_
    """

    return pd.concat([input_table, transformed_batches], axis=1)
