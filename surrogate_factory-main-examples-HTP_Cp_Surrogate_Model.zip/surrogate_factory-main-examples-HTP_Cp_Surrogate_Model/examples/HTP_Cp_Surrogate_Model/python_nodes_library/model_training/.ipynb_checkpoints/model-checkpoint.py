import ast
from typing import Any, Dict, List, Sequence, Union
import pyLOM
from pyLOM.NN import MLP

def _to_list(x: Union[str, Sequence[Any]], cast=None) -> List[Any]:
    # Converts string or list-like object into a Python list
    if isinstance(x, str):
        try:
            val = ast.literal_eval(x)
        except Exception:
            val = [t.strip() for t in x.strip().strip("[]").split(",") if t.strip() != ""]
    else:
        val = list(x)
    if cast is not None:
        val = [cast(v) for v in val]
    return val

def _broadcast_or_list(x: Union[float, int, str, Sequence[Any]], n: int) -> List[float]:
    # Returns a list of floats of length n, broadcasting scalars if necessary
    if isinstance(x, (int, float)):
        return [float(x)] * n
    if isinstance(x, str):
        try:
            return [float(x)] * n
        except Exception:
            vals = _to_list(x, cast=float)
    else:
        vals = list(x)
    if len(vals) == 1:
        return [float(vals[0])] * n
    vals = [float(v) for v in vals]
    if len(vals) != n:
        raise ValueError(f"Dropout length ({len(vals)}) does not match n_layers ({n}).")
    return vals

def build_model(flow_variables: Dict[str, Any]) -> MLP:
    # Extracts model configuration and builds an MLP instance
    try:
        model_block = flow_variables["metadata"]["Model_Selection"]["model"]
        if isinstance(model_block, dict) and len(model_block) > 0:
            print('paso por aqui')
            first_key = next(iter(model_block))
            cfg = model_block[first_key]
        else:
            cfg = model_block
    except Exception as e:
        raise KeyError("Could not locate ['metadata']['Model_Selection']['model'] in flow_variables.") from e

    try:
        algorithm = cfg["algorithm"]
        inputs    = cfg["input"]
        outputs   = cfg["output"]
        hidden    = cfg["hidden_layer_sizes"]
        dropout   = cfg.get("dropout", 0.0)
    except KeyError as e:
        raise KeyError(f"Missing required model key: {e}")

    if str(algorithm).upper() != "MLP":
        raise NotImplementedError(f"Only 'MLP' is supported. Found: {algorithm}")

    input_list  = _to_list(inputs,  cast=str)
    output_list = _to_list(outputs, cast=str)
    if isinstance(hidden, (int, float, str)):
        try:
            hidden_list = _to_list([hidden], cast=int)
        except Exception:
            hidden_list = _to_list(hidden, cast=int)
    else:
        hidden_list = _to_list(hidden, cast=int)

    input_size  = len(input_list)
    output_size = len(output_list)
    n_layers    = len(hidden_list)
    p_dropouts  = _broadcast_or_list(dropout, n_layers)
    
    print(input_size, '\n', output_size, '\n', n_layers, '\n', p_dropouts)

    model = MLP(
        input_size=input_size,
        output_size=output_size,
        hidden_size=hidden_list,
        n_layers=n_layers,
        p_dropouts=p_dropouts,
    )
    return model
