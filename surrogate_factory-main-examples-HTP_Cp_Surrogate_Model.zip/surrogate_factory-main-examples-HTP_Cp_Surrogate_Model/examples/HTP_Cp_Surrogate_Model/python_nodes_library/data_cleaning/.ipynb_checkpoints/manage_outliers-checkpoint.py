import sys
import os.path

import pandas as pd
import numpy as np
from cytoolz.curried import map, get, compose, complement, flip

import surrogate_factory as sf


@sf.node
def filter_outliers(flow_variables, input_table):

    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    outputs_str = list(map(str.strip, outputs.strip('[]').split(',')))

    for output_range in flow_variables['metadata', 'Data_Cleansing', 'Managing_outliers', 'output'].values():
        name = output_range['name']
        range = output_range['range']
        range_list = list(map(str.strip, range.strip('[]').split(',')))
        ranges = np.asarray(range_list, dtype=np.float64)

        if name in outputs_str:
            input_table = input_table[input_table[name].between(ranges[0], ranges[1])]

    return input_table
