import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import validationlib


def compute_metric_statistics(metric_func, yt_df, yh_df, precision=3, nsim=100, method="Bootstrap"):
    """
    Computes and returns a summary table of general statistics for the given metric.
    """
    statistics = {
        "mean": np.mean,
        "median": [np.percentile, {"q": 50}],
        "std": np.std,
        "IQR": st.iqr,
        "kurtosis": st.kurtosis,
        "skewness": st.skew
    }

    displayed_table = validationlib.tables.summary.prediction_stats(
        metric_func(yt_df, yh_df),
        statistics=statistics,
        precision=precision,
        nsim=nsim,
        method=method
    )
    return displayed_table


def compute_metric_percentiles(metric_func, yt_df, yh_df, precision=3, nsim=100, method="Bootstrap"):
    """
    Computes and returns a percentile summary table for the given metric.
    """
    statistics_percentile = {
        f"{i}%": [np.percentile, {"q": i}] for i in [1, 5, 10, 50, 90, 95, 99]
    }

    displayed_table = validationlib.tables.summary.prediction_stats(
        metric_func(yt_df, yh_df),
        statistics=statistics_percentile,
        precision=precision,
        nsim=nsim,
        method=method,
        countMinMax=False
    )
    return displayed_table


def plot_metric_cumulative(metric_func, yt_df, yh_df, bins=1000):
    """
    Plots the cumulative distribution of the given metric.
    """
    metric_df = metric_func(yt_df, yh_df)
    validationlib.plots.cumulative(
        metric_df,
        xlabel=metric_func.name, 
        bins=bins,
        quantiles=[0.1, 0.50, 0.90, 0.95, 0.99]
    )
    plt.show()


def full_metric_analysis(metric_func, yt_df, yh_df):
    """
    Runs the complete statistical and visual analysis for a given metric.
    """
    print(f"Metric: {metric_func.name}")
    stats_table = compute_metric_statistics(metric_func, yt_df, yh_df)
    percentiles_table = compute_metric_percentiles(metric_func, yt_df, yh_df)
    plot_metric_cumulative(metric_func, yt_df, yh_df)
    return stats_table, percentiles_table
