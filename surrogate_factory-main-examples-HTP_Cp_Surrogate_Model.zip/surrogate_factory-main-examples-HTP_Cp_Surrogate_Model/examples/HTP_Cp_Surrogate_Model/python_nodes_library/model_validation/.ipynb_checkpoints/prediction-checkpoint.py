from IPython.display import Markdown
import json
import os, numpy as np, pandas as pd, torch, matplotlib.pyplot as plt
from tqdm import tqdm
import scipy.stats as st
import pyLOM
import pyLOM.NN
from pyLOM.NN import RegressionEvaluator, MinMaxScaler
from typing import Any, Dict

seed = 380
np.random.seed(seed)
torch.manual_seed(seed)

def evaluate(model, training_params, dataset, evaluators, inputs_scaler, outputs_scaler):
    
    y_pred = model.predict(dataset, rescale_output=True, **training_params)
    y_pred = outputs_scaler.inverse_transform(y_pred)
    
    x_true, y_true = dataset[:]
    x_true = inputs_scaler.inverse_transform(x_true)
    y_true = outputs_scaler.inverse_transform(y_true)
    
    return [x_true, y_true, y_pred]


def build_validation_components(flow_variables: Dict[str, Any]):
    """Extract dataloader parameters, evaluator, and scalers from flow_variables."""

    try:
        validation_block = flow_variables["metadata"]["Model_Validation"]
    except Exception as e:
        raise KeyError("Could not locate ['metadata']['Model_Validation'] in flow_variables.") from e

    # ---- Extract dataloader parameters ----
    try:
        dataloader_block = validation_block["dataloader"]
        # Handle {'0': {...}} or direct dict
        if isinstance(dataloader_block, dict) and any(isinstance(v, dict) for v in dataloader_block.values()):
            dataloader_cfg = next(iter(dataloader_block.values()))
        else:
            dataloader_cfg = dataloader_block
    except Exception as e:
        raise KeyError("Could not locate ['dataloader'] parameters in flow_variables.") from e

    def get_value(container: Dict[str, Any], key: str, default=None):
        for k, v in container.items():
            if key.lower() == k.lower():
                return v
        return default

    # Dataloader params
    batch_size  = int(get_value(dataloader_cfg, "batch_size", 32))
    shuffle     = bool(get_value(dataloader_cfg, "shuffle", True))
    num_workers = int(get_value(dataloader_cfg, "num_workers", 0))
    pin_memory  = bool(get_value(dataloader_cfg, "pin_memory", False))

    dataloader_params = {
        "batch_size": batch_size,
        "shuffle": shuffle,
        "num_workers": num_workers,
        "pin_memory": pin_memory,
    }

    # ---- Extract evaluator and scalers (same level as dataloader) ----
    evaluator_name      = str(validation_block.get("evaluator", "RegressionEvaluator")).lower()
    input_scaler_name   = str(validation_block.get("input_scaler", "MinMaxScaler")).lower()
    output_scaler_name  = str(validation_block.get("output_scaler", "MinMaxScaler")).lower()

    # Evaluator
    if "regression" in evaluator_name:
        evaluator = RegressionEvaluator()
    else:
        raise NotImplementedError(f"Unsupported evaluator: {evaluator_name}")

    # Scalers
    if "minmax" in input_scaler_name:
        input_scaler = MinMaxScaler()
    else:
        raise NotImplementedError(f"Unsupported input scaler: {input_scaler_name}")

    if "minmax" in output_scaler_name:
        output_scaler = MinMaxScaler()
    else:
        raise NotImplementedError(f"Unsupported output scaler: {output_scaler_name}")

    return dataloader_params, evaluator, input_scaler, output_scaler
