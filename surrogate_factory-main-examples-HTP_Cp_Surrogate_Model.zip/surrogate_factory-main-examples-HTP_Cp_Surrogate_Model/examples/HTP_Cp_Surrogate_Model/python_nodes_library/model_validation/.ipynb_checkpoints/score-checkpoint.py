from IPython.display import Markdown
import json
import os, numpy as np, pandas as pd, torch, matplotlib.pyplot as plt
from tqdm import tqdm
import scipy.stats as st
import pyLOM
import pyLOM.NN
from pyLOM.NN import RegressionEvaluator, MinMaxScaler
from typing import Any, Dict

seed = 380
np.random.seed(seed)
torch.manual_seed(seed)

def evaluate(model,training_params,dataset,evaluators,inputs_scaler,outputs_scaler):
    
    y_pred = model.predict(dataset, rescale_output=True, **training_params)
    y_pred = outputs_scaler.inverse_transform(y_pred)
    x_true, y_true = dataset[:]
    x_true = inputs_scaler.inverse_transform(x_true)
    y_true = outputs_scaler.inverse_transform(y_true)
    
    metrics = {}
    for evaluator in evaluators:
        metrics.update(evaluator(y_true, y_pred))
        evaluator.print_metrics()
    return metrics, [x_true, y_true, y_pred]


def run_and_save_predictions(model, model_name, datasets, dataset_names, case_dir, dataloader_params, evaluator, input_scaler, output_scaler):
    save_dir = os.path.join(case_dir, 'validation_files', model_name)
    os.makedirs(save_dir, exist_ok=True)

    for dataset, name in zip(datasets, dataset_names):
        _, predictions = evaluate(model, dataloader_params, dataset, [evaluator], input_scaler, output_scaler)
        x, yt, yh = predictions

        pd.DataFrame(x).to_csv(os.path.join(save_dir, f'x_{name}.csv'), index=False, sep = ';', header=None)
        pd.DataFrame(yt, columns=['CP']).to_csv(os.path.join(save_dir, f'yt_{name}.csv'), index=False, sep = ';', header=None)
        pd.DataFrame(yh, columns=['CP']).to_csv(os.path.join(save_dir, f'yh_{name}.csv'), index=False, sep = ';', header=None)

