import pandas as pd
import numpy as np

def _to_numpy(arr):
    try:
        if "torch" in type(arr).__module__:
            return arr.detach().cpu().numpy()
    except Exception:
        pass
    if isinstance(arr, np.ndarray):
        return arr
    return np.asarray(arr)

def dataset_to_df(in_cols, out_cols, dataset_dict):
    
    X = _to_numpy(dataset_dict.__dict__["variables_in"])
    Y = _to_numpy(dataset_dict.__dict__["variables_out"])

    # Asegurar 2D (N, features)
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    else:
        X = X.reshape(X.shape[0], -1)

    if Y.ndim == 1:
        Y = Y.reshape(-1, 1)
    else:
        Y = Y.reshape(Y.shape[0], -1)

    # Validaciones
    if X.shape[0] != Y.shape[0]:
        raise ValueError(f"The number of rows is different between X ({X.shape[0]}) and y ({Y.shape[0]}).")
    if X.shape[1] != len(in_cols):
        raise ValueError(f"X has {X.shape[1]} columns, but it is expected {len(in_cols)}: {in_cols}.")
    if Y.shape[1] != len(out_cols):
        raise ValueError(f"y has {Y.shape[1]} columns, but it is expected {len(out_cols)}: {out_cols}.")

    df_in = pd.DataFrame(X, columns=list(in_cols))
    df_out = pd.DataFrame(Y, columns=list(out_cols))
    return pd.concat([df_in, df_out], axis=1)
