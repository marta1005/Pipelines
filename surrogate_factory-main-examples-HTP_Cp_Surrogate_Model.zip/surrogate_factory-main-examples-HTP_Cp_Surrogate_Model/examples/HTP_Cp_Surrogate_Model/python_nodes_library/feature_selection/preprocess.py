import numpy as np
import pandas as pd
import surrogate_factory as sf

import pickle
import os

import onnx
import joblib
from skl2onnx import convert_sklearn
from skl2onnx.common.data_types import FloatTensorType
from pathlib import Path
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
import pyLOM
import pyLOM.NN


@sf.node
def preprocessor(flow_variables, input_table):

    scaler_fit = {}
    for i, preprocess_def in flow_variables['metadata', 'Feature_selection', 'preprocess'].items():

        inputs = preprocess_def['input']
        if isinstance(inputs, str):
            inputs = list(map(str.strip, inputs.strip('[]').split(',')))

        output = preprocess_def['output']
        method = preprocess_def['method']
        
        if method == 'sklearn.preprocessing.StandardScaler':
            scaler = StandardScaler()

        elif method == 'sklearn.preprocessing.MinMaxScaler':
            scaler = MinMaxScaler()

        elif method == 'sklearn.preprocessing.RobustScaler':
            scaler = RobustScaler()
            
        elif method == 'pyLOM.NN.StandardScaler()':
            scaler = pyLOM.NN.StandardScaler()

        elif method == 'pyLOM.NN.MinMaxScaler()':
            scaler = pyLOM.NN.MinMaxScaler()

        elif method == 'pyLOM.NN.RobustScaler()':
            scaler = pyLOM.NN.RobustScaler()


        # Apply masking of inputs if needed. Not included in this example.
        scaler_fit[i] = scaler.fit(input_table[inputs])

        # Save scaler to file.
        job_name = flow_variables['job_name']
        models_path = Path(flow_variables["data.folder"], "models")

        models_path.mkdir(exist_ok=True)

        file = str(models_path / f'scaler_{job_name}_{output}.pth')
        joblib.dump(scaler_fit[i], file)

        flow_variables['metadata', 'Feature_selection', 'preprocess', i, 'file'] = file

        print(flow_variables['metadata', 'Feature_selection', 'preprocess'])
