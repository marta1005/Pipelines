from surrogate_factory.workflow.doe import DoE
import surrogate_factory as sf


@sf.node
def gather_inputs(flow_variables, input_table):
    doe = DoE.load(flow_variables['doe'])
    return input_table[doe.model_vars()]


@sf.node
def add_features(flow_variables, input_table):

    inputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'inputs']
    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))

    outputs = flow_variables['metadata', 'Feature_selection', 'Add_remove_features', 'outputs']
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))

    for input_name in input_table.columns.values:
        if (input_name not in inputs) and (input_name not in outputs):
            input_table = input_table.drop(input_name, axis=1)
            print(f'Feature {input_name} removed as input.')

    variables = inputs + outputs
    print(variables)
    return input_table
