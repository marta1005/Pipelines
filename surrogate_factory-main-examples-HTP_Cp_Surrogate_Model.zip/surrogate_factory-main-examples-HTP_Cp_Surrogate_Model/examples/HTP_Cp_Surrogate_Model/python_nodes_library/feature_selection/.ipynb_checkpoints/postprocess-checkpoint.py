import numpy as np
import pandas as pd
import surrogate_factory as sf

import pickle
import os


@sf.node
def postprocessor(flow_variables, input_table):
    
    scaler_fit = {}
    for i, postprocess_def in flow_variables['metadata', 'Feature_selection', 'postprocess'].items():

        inputs = postprocess_def['input']
        if isinstance(inputs, str):
            inputs = list(map(str.strip, inputs.strip('[]').split(',')))

        output = postprocess_def['output']
        method =  postprocess_def['method']
        if method == 'pandas':


            ## apply masking of inputs if needed. Not included in this example

            ## save transformer

            pass




    
