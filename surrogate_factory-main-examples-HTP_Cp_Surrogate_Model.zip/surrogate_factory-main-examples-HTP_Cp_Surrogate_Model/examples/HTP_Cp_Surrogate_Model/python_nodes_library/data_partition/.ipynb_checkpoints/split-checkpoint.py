import numpy as np
import pyLOM
import pickle

def load_dataset(fname, fl=None, alpha=None):
    '''
    Auxiliary function to load a dataset into a pyLOM NN dataset
    '''
    d = pyLOM.Dataset.load(fname)
    if fl is not None:
        parameters_idx = [i for i, p in enumerate(d.get_variable('FL')) if p == fl]
        if alpha is not None:
            parameters_idx = [i for i in parameters_idx if d.get_variable('aoa')[i] >= alpha[0] and d.get_variable('aoa')[i] <= alpha[1]]
    else:
        parameters_idx = range(len(d.get_variable('FL')))
    alpha   = [d.get_variable('aoa')[i] for i in parameters_idx]
    mach    = [d.get_variable('M')[i] for i in parameters_idx]
    fl_list = [d.get_variable('FL')[i] for i in parameters_idx]
    cp      = d["CoefPressure"][:, parameters_idx]
    td = pyLOM.NN.Dataset(
        variables_out=(cp,), 
        variables_in=np.hstack((d.xyz, d['Zone'])),
        # to have each Mach and AoA pair just once. 
        # To have all possible combinations, use [d.get_variable('AoA'), d.get_variable("Mach")]
        parameters=[alpha, mach] if fl is not None else [alpha, mach, fl_list],
    )
    return d, td

def scale_data(inputs, outputs, inputs_scaler, outputs_scaler):
    if inputs_scaler.is_fitted:
        inputs = inputs_scaler.transform(inputs)
    else:
        inputs = inputs_scaler.fit_transform(inputs)
    
    if outputs_scaler.is_fitted:
        outputs = outputs_scaler.transform(outputs)
    else:
        outputs = outputs_scaler.fit_transform(outputs)

    with open('scalers.pkl', 'wb') as f: 
        pickle.dump({
            "input_scaler": inputs_scaler, 
            "output_scaler": outputs_scaler
        }, f)
    
    return inputs, outputs

def unscale_data(inputs, outputs, inputs_scaler, outputs_scaler):
    if inputs_scaler.is_fitted:
        inputs = inputs_scaler.inverse_transform(inputs)
    else:
        raise ValueError("The inputs scaler has not been fitted yet.")
    
    if outputs_scaler.is_fitted:
        outputs = outputs_scaler.inverse_transform(outputs)
    else:
        raise ValueError("The outputs scaler has not been fitted yet.")
    
    return inputs, outputs

def filter_by_zone(inputs, outputs, zone):
    return (inputs[:, 3] == zone).tolist()

def get_split_indices_by_fc(all_data, fc_list, expanded_fc_list):
    subset_fc_indices = [] # This stores the indices of each sample in all_data that corresponds to the specified flight conditions
    subset_params_indices = [] # This stores the indices of each flight condition in all_data.parameters that corresponds to the specified flight conditions

    # For each flight condition in fc_list, find the indices in all_data that match the flight condition,
    # store them in subset_fc_indices and subset_params_indices. Also store the indices of the parameters
    # in all_data.parameters that match the flight condition.
    for fc_idx, (alpha, mach) in enumerate(fc_list):
        subset_fc_indices.append(np.where(np.isclose(expanded_fc_list, [alpha, mach], atol=1e-5).all(axis=1))[0])
        subset_params_indices.append(np.where(np.isclose(all_data.parameters, [alpha, mach], atol=1e-5).all(axis=1))[0])

    subset_fc_indices = np.concatenate(subset_fc_indices)
    subset_params_indices = np.concatenate(subset_params_indices)

    return subset_fc_indices, subset_params_indices

def get_subset_by_indices(all_data, subset_fc_indices, subset_params_indices):
    return pyLOM.NN.Dataset(
        variables_out=(all_data.variables_out[subset_fc_indices],),
        mesh_shape = all_data.mesh_shape,
        variables_in = all_data.variables_in.numpy(),
        parameters = all_data.parameters[subset_params_indices].T.tolist(),
        combine_parameters_with_cartesian_prod=False,
        snapshots_by_column=False
    )

def subset_preprocessing(subset, input_scaler, output_scaler, flow_variables):
    ZONE = flow_variables['metadata']["Data_Partition"]["ZONE"]
    subset = subset.filter(
        filter_by_zone,
        batched=True,
        fn_kwargs={"zone": ZONE},
        batch_size=len(subset),
        return_views=False,
    )

    subset.remove_column(3, from_variables_out=False)

    subset.map(
        scale_data,
        fn_kwargs={"inputs_scaler": input_scaler, "outputs_scaler": output_scaler},
        batched=True,
        batch_size=len(subset),
    )

    return subset