import numpy as np
from pandas import DataFrame
import surrogate_factory as sf


DFS_PATH = "./validation_files/MLP"
    
@sf.node
def data_split(flow_variables, input_table):
    """_summary_
    Function to split data in the 3 datasets for training, test and validation
    flow_variables should be updated accordingly
    Args:
        flow_variables (_type_): flow_variables of the pipeline
        input_table (_type_): Dataset to split

    Returns:
        Train_set: pandas DataFrame
        Test_set: pandas DataFrame
        Val_set: pandas DataFrame

    """

    train_perc = flow_variables["metadata", "Data_Partition", "percentages", "train"]
    test_perc = (flow_variables["metadata", "Data_Partition", "percentages", "test"])
    val_perc = 1 - test_perc

    inputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'inputs']
    if isinstance(inputs, str):
        inputs = list(map(str.strip, inputs.strip('[]').split(',')))

    outputs = flow_variables['metadata', 'Data_acquisition_generation', 'Data_acquisition', 'Extract', 'outputs']
    if isinstance(outputs, str):
        outputs = list(map(str.strip, outputs.strip('[]').split(',')))

    for input_name in input_table.columns.values:
        if (input_name not in inputs) and (input_name not in outputs):
            input_table = input_table.drop(input_name, axis=1)
            print(f'{input_name} removed as input.')

    train_set, val_set, test_set = np.split(input_table.sample(frac=1, random_state=42), [int(train_perc*len(input_table)), int(val_perc*len(input_table))])

    flow_variables['metadata', 'Data_Partition', 'size', 'train'] = train_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'test'] = test_set.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'validation'] = val_set.shape[0]

    return train_set, val_set, test_set

@sf.node
def data_split_fc(flow_variables, input_table): 
    
    import pandas as pd
    import numpy as np 
    import os
    
    print(DFS_PATH)
    
    # If dataframes are saved as numpy arrays, use the following lines
    x_train_df = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "x_train.csv"), delimiter=";"), columns=["x", "y", "z", "alpha", "mach"])
    x_test_df  = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "x_test.csv"), delimiter=";"), columns=["x", "y", "z", "alpha", "mach"])
    x_val_df   = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "x_val.csv"), delimiter=";"), columns=["x", "y", "z", "alpha", "mach"])

    yt_train_df = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "yt_train.csv"), delimiter=";"), columns=["cp"])
    yt_test_df  = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "yt_test.csv"), delimiter=";"), columns=["cp"])
    yt_val_df   = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "yt_val.csv"), delimiter=";"), columns=["cp"])

    yh_val_df   = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "yh_val.csv"), delimiter=";"), columns=["cp"])
    yh_test_df  = pd.DataFrame(np.loadtxt(os.path.join(DFS_PATH, "yh_test.csv"), delimiter=";"), columns=["cp"])

    # names used 
    input_names = x_train_df.columns
    output_names = yt_train_df.columns
    
    # Get all the test data that has the same alpha and mach as the training data and remove it from the test set
    used_test_indices = ~x_test_df.set_index(["alpha", "mach"]).index.isin(x_train_df.set_index(["alpha", "mach"]).index)
    used_val_indices  = ~x_val_df.set_index(["alpha", "mach"]).index.isin(x_train_df.set_index(["alpha", "mach"]).index)

    x_test_df  = x_test_df[used_test_indices]
    yt_test_df = yt_test_df[used_test_indices]
    yh_test_df = yh_test_df[used_test_indices]

    x_val_df   = x_val_df[used_val_indices]
    yt_val_df  = yt_val_df[used_val_indices]
    yh_val_df  = yh_val_df[used_val_indices]
    
    # data split
    fc_train = np.array(list(x_train_df.groupby(["alpha", "mach"]).groups.keys()))
    fc_test  = np.array(list(x_test_df.groupby(["alpha", "mach"]).groups.keys()))
    fc_val   = np.array(list(x_val_df.groupby(["alpha", "mach"]).groups.keys()))
    
    # save the data into the variables 
    flow_variables['metadata', 'Data_Partition', 'size', 'train']      = fc_train.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'test']       = fc_test.shape[0]
    flow_variables['metadata', 'Data_Partition', 'size', 'validation'] = fc_val.shape[0]
    
    return fc_train, fc_val, fc_test
