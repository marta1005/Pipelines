from IPython.display import display, HTML, JSON
import sys
import os.path

import json

from pathlib import Path
import json
import pandas as pd
import surrogate_factory as sf
# from surrogate_factory.workflow.tune import Hypertuning_params


@sf.node
def define_model(flow_variables, input_table: pd.DataFrame, hypertuning=None, output=None):
    # HT_set = flow_variables['metadata']['Model_Selection']['algorithms']
    if hypertuning is not None:
        flow_variables['metadata']['Model_Selection']['Hypertuning'] = hypertuning
    if flow_variables['metadata']['Model_Selection']['Hypertuning'] is True:
        #best_param = Hypertuning_params(flow_variables, input_table, output)
        outputs = flow_variables['metadata']['Feature_selection']['Add_remove_features']['outputs']
        if isinstance(outputs, str):
            outputs = list(map(str.strip, outputs.strip('[]').split(',')))
        print(f'output by user:{len(outputs)}')
        # for RF in best_param.keys():
        #     for coln in range(len(outputs)):
        #         if flow_variables['metadata']['Model_Selection']['algorithms'][coln]['output'] == RF:
        #             flow_variables['metadata']['Model_Selection']['algorithms'][coln]['settings'] = best_param[RF]
        #             HT_set[coln]['settings']['deep'] = best_param[RF]['deep']
        #             break
        #         else:
        #             pass

    return flow_variables
